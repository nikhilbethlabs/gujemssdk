//
//  MASTSDelegateThirdParty.h
//  Samples
//
//  Created by Jason Dickert on 4/21/12.
//  Copyright (c) 2012 mOcean Mobile. All rights reserved.
//

#import "MASTSDelegate.h"

@interface MASTSDelegateThirdParty : MASTSDelegate

@end

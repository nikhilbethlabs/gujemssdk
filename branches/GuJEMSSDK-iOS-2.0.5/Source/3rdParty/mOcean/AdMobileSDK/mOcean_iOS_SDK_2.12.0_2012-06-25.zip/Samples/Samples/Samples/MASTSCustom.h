//
//  MASTSCustom.h
//  AdMobileSamples
//
//  Created by Jason Dickert on 4/18/12.
//  Copyright (c) 2012 mOcean Mobile. All rights reserved.
//

#import "MASTSSimple.h"
#import "MASTSCustomConfigController.h"

@interface MASTSCustom : MASTSSimple <MASTSCustomConfigDelegate>

@end

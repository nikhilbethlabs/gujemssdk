//
//  MASTSSimpleRichMedia.h
//  MASTSamples
//
//  Created by Jason Dickert on 4/17/12.
//  Copyright (c) 2012 mOcean Mobile. All rights reserved.
//

#import "MASTSSimple.h"

@interface MASTSSimpleRichMedia : MASTSSimple

@end

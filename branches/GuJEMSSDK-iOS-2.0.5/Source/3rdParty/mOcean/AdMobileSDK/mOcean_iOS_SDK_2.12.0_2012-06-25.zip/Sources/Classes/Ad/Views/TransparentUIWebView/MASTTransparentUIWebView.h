//
//  TransparentUIWebView.h
//  AdMobileSDK
//
//  Created by Constantine Mureev on 6/28/11.
//  Copyright 2011 AdMobile Mobile. A subsidiary of Mojiva, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MASTUIViewAdditions.h"


@interface MASTTransparentUIWebView : UIWebView {
    
}

@end

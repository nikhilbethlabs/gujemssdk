//
//  FileManager.h
//  AdMobileSDK
//
//  Created by Constantine Mureev on 3/16/11.
//

#import <Foundation/Foundation.h>


@interface MASTFileManager : NSObject {
    
}

@end

var GUJAdViewContextVersion_8h =
[
    [ "LIB_GUJ_AD_VIEW_CONTEXT_MAJOR_VERSION", "GUJAdViewContextVersion_8h.html#a5b05627eb1e821f721864fa2942a5fdb", null ],
    [ "LIB_GUJ_AD_VIEW_CONTEXT_MINOR_VERSION", "GUJAdViewContextVersion_8h.html#a96096c94cecd035a95018741d7bb334f", null ],
    [ "LIB_GUJ_AD_VIEW_CONTEXT_REVISION", "GUJAdViewContextVersion_8h.html#ab29ae7483f3ae37416ab708d54c2b54d", null ],
    [ "LIB_GUJ_AD_VIEW_CONTEXT_VERSION", "GUJAdViewContextVersion_8h.html#ae53227c14d37cd41b163e64a7917a261", null ],
    [ "LIB_GUJ_AD_VIEW_CONTEXT_VERSION_CHECK", "GUJAdViewContextVersion_8h.html#a1c4569239e2f7f5b22a7e13aa5a26721", null ]
];
var files =
[
    [ "GUJAdViewContext.h", "GUJAdViewContext_8h.html", [
      [ "GUJAdView", "interfaceGUJAdView.html", "interfaceGUJAdView" ],
      [ "GUJAdViewContext", "interfaceGUJAdViewContext.html", "interfaceGUJAdViewContext" ]
    ] ],
    [ "GUJAdViewContext.m", "GUJAdViewContext_8m.html", "GUJAdViewContext_8m" ],
    [ "GUJAdViewContextConstants.h", "GUJAdViewContextConstants_8h.html", "GUJAdViewContextConstants_8h" ],
    [ "GUJAdViewContextLocalTypeDefinition.h", "GUJAdViewContextLocalTypeDefinition_8h.html", "GUJAdViewContextLocalTypeDefinition_8h" ],
    [ "GUJAdViewContextVersion.h", "GUJAdViewContextVersion_8h.html", "GUJAdViewContextVersion_8h" ]
];
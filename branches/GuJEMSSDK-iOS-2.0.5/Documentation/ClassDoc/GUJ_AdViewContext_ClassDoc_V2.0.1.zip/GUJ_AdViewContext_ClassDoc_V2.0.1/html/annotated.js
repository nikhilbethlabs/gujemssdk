var annotated =
[
    [ "GUJAdView", "interfaceGUJAdView.html", "interfaceGUJAdView" ],
    [ "GUJAdViewContext", "interfaceGUJAdViewContext.html", "interfaceGUJAdViewContext" ],
    [ "NSObject", "classNSObject.html", null ],
    [ "UIView", "classUIView.html", null ]
];
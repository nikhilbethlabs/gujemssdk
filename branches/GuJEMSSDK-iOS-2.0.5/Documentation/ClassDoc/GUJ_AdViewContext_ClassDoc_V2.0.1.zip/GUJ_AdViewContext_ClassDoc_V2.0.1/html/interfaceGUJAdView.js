var interfaceGUJAdView =
[
    [ "adSpaceId", "interfaceGUJAdView.html#a378263deb632c34802d8fc1f2f51678c", null ],
    [ "hide", "interfaceGUJAdView.html#a4f13dcb423bd83b842d10aa189a3006f", null ],
    [ "show", "interfaceGUJAdView.html#a5048ad5e35d8c5e6edf1a44aeaef7756", null ],
    [ "showInterstitialView", "interfaceGUJAdView.html#a5d2c567fa504a06a6962e4a7d873a4fa", null ]
];
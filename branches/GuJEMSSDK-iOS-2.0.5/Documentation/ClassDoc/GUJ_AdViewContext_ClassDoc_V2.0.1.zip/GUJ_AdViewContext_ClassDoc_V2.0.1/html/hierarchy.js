var hierarchy =
[
    [ "NSObject", "classNSObject.html", [
      [ "GUJAdViewContext", "interfaceGUJAdViewContext.html", null ]
    ] ],
    [ "UIView", "classUIView.html", [
      [ "GUJAdView", "interfaceGUJAdView.html", null ]
    ] ]
];
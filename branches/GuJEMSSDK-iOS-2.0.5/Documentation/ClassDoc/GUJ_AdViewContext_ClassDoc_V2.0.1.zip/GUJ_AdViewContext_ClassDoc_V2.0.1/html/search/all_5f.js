var searchData=
[
  ['_5f_5finitgujadviewcontroller_3asite_3azone_3adelegate_3a',['__initGUJAdViewController:site:zone:delegate:',['../interfaceGUJAdViewContext.html#ac93a5a898e4d783c2e4a234184d0b391',1,'GUJAdViewContext']]],
  ['_5fgujvcinstance_5f',['_GUJVCInstance_',['../GUJAdViewContext_8m.html#aae75e312632d0e9187a2666d4fb5d229',1,'GUJAdViewContext.m']]]
];

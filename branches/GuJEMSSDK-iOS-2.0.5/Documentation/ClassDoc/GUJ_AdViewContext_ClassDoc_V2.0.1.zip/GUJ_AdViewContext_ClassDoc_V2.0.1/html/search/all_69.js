var searchData=
[
  ['initalizationattempts_3a',['initalizationAttempts:',['../interfaceGUJAdViewContext.html#a853b0b93c95fc539b7dd4f62641ea571',1,'GUJAdViewContext']]],
  ['instanceforadspaceid_3a',['instanceForAdspaceId:',['../interfaceGUJAdViewContext.html#a51c07572c4e8322492f6c7c7a26c587f',1,'GUJAdViewContext']]],
  ['instanceforadspaceid_3adelegate_3a',['instanceForAdspaceId:delegate:',['../interfaceGUJAdViewContext.html#a172db116c2ed69e3461fb059b8da0747',1,'GUJAdViewContext']]],
  ['instanceforadspaceid_3asite_3azone_3a',['instanceForAdspaceId:site:zone:',['../interfaceGUJAdViewContext.html#a3747f3eeb2081051a7fbe95a89319cf0',1,'GUJAdViewContext']]],
  ['instanceforadspaceid_3asite_3azone_3adelegate_3a',['instanceForAdspaceId:site:zone:delegate:',['../interfaceGUJAdViewContext.html#aa8e64d2e4352f1bc85e9c1bddcd55bb5',1,'GUJAdViewContext']]],
  ['interstitialadview',['interstitialAdView',['../interfaceGUJAdViewContext.html#a4d8b72fa06649447bcd5e3fdfcfd0010',1,'GUJAdViewContext']]],
  ['interstitialadviewforkeywords_3a',['interstitialAdViewForKeywords:',['../interfaceGUJAdViewContext.html#af70ce43dfdec3131232655b4abba5dd4',1,'GUJAdViewContext']]],
  ['interstitialadviewforkeywords_3acompletion_3a',['interstitialAdViewForKeywords:completion:',['../interfaceGUJAdViewContext.html#a8fba01d51dc4e449a80f0cef5ae27d75',1,'GUJAdViewContext']]],
  ['interstitialadviewwithcompletionhandler_3a',['interstitialAdViewWithCompletionHandler:',['../interfaceGUJAdViewContext.html#a3d9a61e09deb669a79935a8ad33db1b9',1,'GUJAdViewContext']]]
];

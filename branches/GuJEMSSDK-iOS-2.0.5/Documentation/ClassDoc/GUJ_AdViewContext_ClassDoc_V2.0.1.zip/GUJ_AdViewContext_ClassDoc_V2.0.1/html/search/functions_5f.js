var searchData=
[
  ['_5f_5finitgujadviewcontroller_3asite_3azone_3adelegate_3a',['__initGUJAdViewController:site:zone:delegate:',['../interfaceGUJAdViewContext.html#ac93a5a898e4d783c2e4a234184d0b391',1,'GUJAdViewContext']]]
];

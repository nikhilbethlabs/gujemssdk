var searchData=
[
  ['freeinstance',['freeInstance',['../interfaceGUJAdViewContext.html#a7849c237774f7a4a69051c715515f0a3',1,'GUJAdViewContext']]]
];

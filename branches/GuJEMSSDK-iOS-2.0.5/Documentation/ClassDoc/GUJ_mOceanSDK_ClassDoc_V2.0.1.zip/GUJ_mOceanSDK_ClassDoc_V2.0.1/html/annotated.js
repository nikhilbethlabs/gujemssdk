var annotated =
[
    [ "_GUJAdView", "class__GUJAdView.html", null ],
    [ "GUJAdView", "interfaceGUJAdView.html", null ],
    [ "GUJMASTAdViewRef", "interfaceGUJMASTAdViewRef.html", "interfaceGUJMASTAdViewRef" ],
    [ "GUJmOceanBridge", "interfaceGUJmOceanBridge.html", "interfaceGUJmOceanBridge" ],
    [ "GUJmOceanBridge(PrivateImplementation)", "categoryGUJmOceanBridge_07PrivateImplementation_08.html", "categoryGUJmOceanBridge_07PrivateImplementation_08" ],
    [ "GUJmOceanUtil", "interfaceGUJmOceanUtil.html", "interfaceGUJmOceanUtil" ],
    [ "GUJmOceanViewController", "interfaceGUJmOceanViewController.html", "interfaceGUJmOceanViewController" ],
    [ "GUJmOceanViewController(PrivateImplementation)", "categoryGUJmOceanViewController_07PrivateImplementation_08.html", "categoryGUJmOceanViewController_07PrivateImplementation_08" ],
    [ "GUJmOceanViewController(PrivateImplementationDelegate)", "categoryGUJmOceanViewController_07PrivateImplementationDelegate_08.html", null ],
    [ "NSObject", "classNSObject.html", null ],
    [ "<NSObject>", "classNSObject-p.html", null ],
    [ "ORMMAViewController", "classORMMAViewController.html", null ],
    [ "UIView", "classUIView.html", null ],
    [ "<UIViewGUJAdViewDelegate>", "classUIViewGUJAdViewDelegate-p.html", null ]
];
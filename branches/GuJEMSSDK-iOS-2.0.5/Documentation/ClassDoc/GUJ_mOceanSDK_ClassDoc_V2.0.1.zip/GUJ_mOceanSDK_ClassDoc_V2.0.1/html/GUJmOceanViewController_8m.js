var GUJmOceanViewController_8m =
[
    [ "GUJAdView", "interfaceGUJAdView.html", null ],
    [ "GUJmOceanViewController(PrivateImplementationDelegate)", "categoryGUJmOceanViewController_07PrivateImplementationDelegate_08.html", null ],
    [ "mOceanBridge", "GUJmOceanViewController_8m.html#a32e61e5dbc1a8e5cbf6bd428f021bfe7", null ]
];
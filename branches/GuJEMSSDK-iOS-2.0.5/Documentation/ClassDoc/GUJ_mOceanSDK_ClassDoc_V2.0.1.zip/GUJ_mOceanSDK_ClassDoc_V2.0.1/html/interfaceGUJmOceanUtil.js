var interfaceGUJmOceanUtil =
[
    [ "adContentTypeForMASTAdView:", "interfaceGUJmOceanUtil.html#a160a183fcbcbd6f34ebcb25bd0f9e948", null ],
    [ "adModelForMASTAdView:", "interfaceGUJmOceanUtil.html#a8cf1c24dc60b732e3eeb0983f29c5a70", null ],
    [ "adTypeForMASTAdView:", "interfaceGUJmOceanUtil.html#aa0106816e677bc015ae51ee0fd400cc6", null ],
    [ "descriptorForMASTAdView:", "interfaceGUJmOceanUtil.html#a1046e746dfd2fad7b58bdf6374edcdcc", null ],
    [ "serverResponseForMASTAdView:", "interfaceGUJmOceanUtil.html#aedc31f1c143e56d89a5324b9c2dcb4cb", null ],
    [ "urlForMASTAdView:", "interfaceGUJmOceanUtil.html#a4b91651eb4203fc46ca4ac4295609b7a", null ]
];
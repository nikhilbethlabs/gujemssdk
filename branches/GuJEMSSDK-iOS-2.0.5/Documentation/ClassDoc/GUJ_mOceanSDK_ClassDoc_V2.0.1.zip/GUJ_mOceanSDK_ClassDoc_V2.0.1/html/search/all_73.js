var searchData=
[
  ['serverresponseformastadview_3a',['serverResponseForMASTAdView:',['../interfaceGUJmOceanUtil.html#aedc31f1c143e56d89a5324b9c2dcb4cb',1,'GUJmOceanUtil']]],
  ['setmastadviewref_3a',['setMastAdViewRef:',['../interfaceGUJMASTAdViewRef.html#aeddb41e6fe67e91edd8e738424782450',1,'GUJMASTAdViewRef']]]
];

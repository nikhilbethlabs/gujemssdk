var searchData=
[
  ['gujadview',['gujAdView',['../interfaceGUJmOceanBridge.html#af44a2f1acf40130ae90e34824b046595',1,'GUJmOceanBridge']]],
  ['gujadviewref',['gujAdViewRef',['../interfaceGUJMASTAdViewRef.html#a5d63fb5a71303f1f7252fb60aa948da2',1,'GUJMASTAdViewRef']]]
];

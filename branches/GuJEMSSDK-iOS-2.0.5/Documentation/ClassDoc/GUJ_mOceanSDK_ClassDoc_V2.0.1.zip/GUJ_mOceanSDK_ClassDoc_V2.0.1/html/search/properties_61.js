var searchData=
[
  ['adconfiguration',['adConfiguration',['../interfaceGUJmOceanBridge.html#a2f7a725fecafa49166c6782b19115a9a',1,'GUJmOceanBridge']]],
  ['adviewdelegate',['adViewDelegate',['../interfaceGUJmOceanBridge.html#a03f4924ca86e57cd4d09ddd54f1b23b1',1,'GUJmOceanBridge']]]
];

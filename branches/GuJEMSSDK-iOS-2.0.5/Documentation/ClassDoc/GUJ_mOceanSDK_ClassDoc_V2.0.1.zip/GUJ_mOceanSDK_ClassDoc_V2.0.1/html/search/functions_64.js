var searchData=
[
  ['descriptorformastadview_3a',['descriptorForMASTAdView:',['../interfaceGUJmOceanUtil.html#a1046e746dfd2fad7b58bdf6374edcdcc',1,'GUJmOceanUtil']]],
  ['didclosedad_3ausagetimeinterval_3a',['didClosedAd:usageTimeInterval:',['../interfaceGUJmOceanBridge.html#ae2ca1b0f75d2fa7721d75d1c6204e8d2',1,'GUJmOceanBridge']]],
  ['didfailtoreceivead_3awitherror_3a',['didFailToReceiveAd:withError:',['../interfaceGUJmOceanBridge.html#aba6e9ccfbf4b608aa2b5a401dacf0dfc',1,'GUJmOceanBridge']]],
  ['didreceivead_3a',['didReceiveAd:',['../interfaceGUJmOceanBridge.html#a3bf1aa2df3ca9a34bd4cd9ae74680c7b',1,'GUJmOceanBridge']]],
  ['didreceivethirdpartyrequest_3acontent_3a',['didReceiveThirdPartyRequest:content:',['../interfaceGUJmOceanBridge.html#a8b7d0b84b7042d5932f4249d481dbba9',1,'GUJmOceanBridge']]]
];

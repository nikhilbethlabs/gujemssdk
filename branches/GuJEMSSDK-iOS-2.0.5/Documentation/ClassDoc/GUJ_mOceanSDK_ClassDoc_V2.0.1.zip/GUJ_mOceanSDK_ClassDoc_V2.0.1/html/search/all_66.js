var searchData=
[
  ['freeinstance',['freeInstance',['../interfaceGUJmOceanBridge.html#a4dce98e8373a8948a3e6fba952e7dfd5',1,'GUJmOceanBridge::freeInstance()'],['../interfaceGUJmOceanViewController.html#aeb6a5049a0cb28f50566d3ef00e8a9c2',1,'GUJmOceanViewController::freeInstance()']]]
];

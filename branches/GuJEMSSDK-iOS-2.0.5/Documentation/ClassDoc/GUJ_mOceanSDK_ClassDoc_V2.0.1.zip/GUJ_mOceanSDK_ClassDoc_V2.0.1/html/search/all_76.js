var searchData=
[
  ['view_3adidfailtoloadadwithurl_3aanderror_3a',['view:didFailToLoadAdWithUrl:andError:',['../categoryGUJmOceanViewController_07PrivateImplementation_08.html#acfb6c22ae6274032fbca4b3332313a2a',1,'GUJmOceanViewController(PrivateImplementation)::view:didFailToLoadAdWithUrl:andError:()'],['../interfaceGUJmOceanViewController.html#acfb6c22ae6274032fbca4b3332313a2a',1,'GUJmOceanViewController::view:didFailToLoadAdWithUrl:andError:()']]]
];

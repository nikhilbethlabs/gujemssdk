var searchData=
[
  ['urlformastadview_3a',['urlForMASTAdView:',['../interfaceGUJmOceanUtil.html#a4b91651eb4203fc46ca4ac4295609b7a',1,'GUJmOceanUtil']]]
];

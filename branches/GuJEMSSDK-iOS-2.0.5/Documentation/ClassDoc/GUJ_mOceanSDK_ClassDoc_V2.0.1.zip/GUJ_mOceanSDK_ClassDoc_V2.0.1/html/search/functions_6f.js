var searchData=
[
  ['ormmaprocess_3aevent_3aparameters_3a',['ormmaProcess:event:parameters:',['../interfaceGUJmOceanBridge.html#ae8ee09cadb48c42e854b5d37a25b7cdd',1,'GUJmOceanBridge']]]
];

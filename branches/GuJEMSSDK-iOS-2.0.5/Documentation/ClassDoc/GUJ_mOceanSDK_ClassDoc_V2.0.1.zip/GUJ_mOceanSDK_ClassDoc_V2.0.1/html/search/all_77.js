var searchData=
[
  ['willreceivead_3a',['willReceiveAd:',['../interfaceGUJmOceanBridge.html#a9263b813325c9eac7b5be9659ec4760c',1,'GUJmOceanBridge']]]
];

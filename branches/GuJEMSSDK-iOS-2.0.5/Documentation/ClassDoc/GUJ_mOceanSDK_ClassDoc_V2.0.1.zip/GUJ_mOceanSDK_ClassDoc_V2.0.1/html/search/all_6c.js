var searchData=
[
  ['lib_5fguj_5fmocean_5fsdk_5fmajor_5fversion',['LIB_GUJ_MOCEAN_SDK_MAJOR_VERSION',['../GUJmOceanSDKVersion_8h.html#a68c8f35e3ca653f9ede2585524739648',1,'GUJmOceanSDKVersion.h']]],
  ['lib_5fguj_5fmocean_5fsdk_5fminor_5fversion',['LIB_GUJ_MOCEAN_SDK_MINOR_VERSION',['../GUJmOceanSDKVersion_8h.html#a4dd19230165119b13abdb288c899133b',1,'GUJmOceanSDKVersion.h']]],
  ['lib_5fguj_5fmocean_5fsdk_5frevision',['LIB_GUJ_MOCEAN_SDK_REVISION',['../GUJmOceanSDKVersion_8h.html#a42db573c7f2cd23257d6756538d8cd41',1,'GUJmOceanSDKVersion.h']]],
  ['lib_5fguj_5fmocean_5fsdk_5fversion',['LIB_GUJ_MOCEAN_SDK_VERSION',['../GUJmOceanSDKVersion_8h.html#a85d061e9d7f0f2192393db15f2a3be42',1,'GUJmOceanSDKVersion.h']]],
  ['lib_5fguj_5fmocean_5fsdk_5fversion_5fcheck',['LIB_GUJ_MOCEAN_SDK_VERSION_CHECK',['../GUJmOceanSDKVersion_8h.html#a67f4ce13bd74b8f4a2d0d5bb79094537',1,'GUJmOceanSDKVersion.h']]]
];

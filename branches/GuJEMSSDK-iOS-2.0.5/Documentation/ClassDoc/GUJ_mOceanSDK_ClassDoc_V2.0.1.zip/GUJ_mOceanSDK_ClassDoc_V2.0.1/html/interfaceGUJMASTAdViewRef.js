var interfaceGUJMASTAdViewRef =
[
    [ "setMastAdViewRef:", "interfaceGUJMASTAdViewRef.html#aeddb41e6fe67e91edd8e738424782450", null ],
    [ "gujAdViewRef", "interfaceGUJMASTAdViewRef.html#a5d63fb5a71303f1f7252fb60aa948da2", null ],
    [ "mastAdViewRef", "interfaceGUJMASTAdViewRef.html#ada2d7c1ae99046b9e3320af4d96a7cac", null ]
];
var hierarchy =
[
    [ "_GUJAdView", "class__GUJAdView.html", [
      [ "GUJMASTAdViewRef", "interfaceGUJMASTAdViewRef.html", null ]
    ] ],
    [ "GUJmOceanBridge(PrivateImplementation)", "categoryGUJmOceanBridge_07PrivateImplementation_08.html", null ],
    [ "GUJmOceanViewController(PrivateImplementation)", "categoryGUJmOceanViewController_07PrivateImplementation_08.html", null ],
    [ "NSObject", "classNSObject.html", [
      [ "GUJmOceanBridge", "interfaceGUJmOceanBridge.html", null ],
      [ "GUJmOceanUtil", "interfaceGUJmOceanUtil.html", null ]
    ] ],
    [ "<NSObject>", "classNSObject-p.html", [
      [ "GUJmOceanBridge", "interfaceGUJmOceanBridge.html", null ]
    ] ],
    [ "ORMMAViewController", "classORMMAViewController.html", [
      [ "GUJmOceanViewController", "interfaceGUJmOceanViewController.html", null ],
      [ "GUJmOceanViewController", "interfaceGUJmOceanViewController.html", null ],
      [ "GUJmOceanViewController", "interfaceGUJmOceanViewController.html", null ],
      [ "GUJmOceanViewController", "interfaceGUJmOceanViewController.html", null ],
      [ "GUJmOceanViewController", "interfaceGUJmOceanViewController.html", null ]
    ] ],
    [ "UIView", "classUIView.html", [
      [ "GUJAdView", "interfaceGUJAdView.html", null ]
    ] ],
    [ "<UIViewGUJAdViewDelegate>", "classUIViewGUJAdViewDelegate-p.html", [
      [ "GUJmOceanViewController(PrivateImplementationDelegate)", "categoryGUJmOceanViewController_07PrivateImplementationDelegate_08.html", null ]
    ] ]
];
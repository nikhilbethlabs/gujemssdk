var searchData=
[
  ['initialplacementid_5f',['initialPlacementId_',['../interfaceORMMAXAXISView.html#a1788857fd4036e710af8d6bd45eb3cd4',1,'ORMMAXAXISView']]],
  ['instanceforadspaceid_3a',['instanceForAdspaceId:',['../interfaceGUJXAXISViewController.html#a6c8e92112e218dc87034b1485ee7a092',1,'GUJXAXISViewController']]],
  ['instanceforadspaceid_3adelegate_3a',['instanceForAdspaceId:delegate:',['../interfaceGUJXAXISViewController.html#a6974fe472e5e27a7bce0ca9dd31cf3ba',1,'GUJXAXISViewController']]],
  ['instanceforadspaceid_3asite_3azone_3a',['instanceForAdspaceId:site:zone:',['../interfaceGUJXAXISViewController.html#abd9d4e053197af8ace3f202a521bd2f3',1,'GUJXAXISViewController']]],
  ['instanceforadspaceid_3asite_3azone_3adelegate_3a',['instanceForAdspaceId:site:zone:delegate:',['../interfaceGUJXAXISViewController.html#acfcc0b46c55bf62788455a6bac747593',1,'GUJXAXISViewController']]],
  ['isxaxisvideoad',['isXAXISVideoAd',['../interfaceORMMAXAXISView.html#aada709279b237d39b19d4a5fe0a7e645',1,'ORMMAXAXISView']]],
  ['isxaxisvideoad_5f',['isXAXISVideoAd_',['../interfaceORMMAXAXISView.html#a5e462506f80b829adfea37e214a5deef',1,'ORMMAXAXISView']]]
];

var searchData=
[
  ['lib_5fguj_5fxaxis_5fsdk_5fmajor_5fversion',['LIB_GUJ_XAXIS_SDK_MAJOR_VERSION',['../GUJXAXISSDKVersion_8h.html#ad566d2ff971680fc8be84fa19c0c3aa9',1,'GUJXAXISSDKVersion.h']]],
  ['lib_5fguj_5fxaxis_5fsdk_5fminor_5fversion',['LIB_GUJ_XAXIS_SDK_MINOR_VERSION',['../GUJXAXISSDKVersion_8h.html#ae40e19fc5daf8e7f3baf07e596796be5',1,'GUJXAXISSDKVersion.h']]],
  ['lib_5fguj_5fxaxis_5fsdk_5frevision',['LIB_GUJ_XAXIS_SDK_REVISION',['../GUJXAXISSDKVersion_8h.html#ac96324007cf14e5ae0ab76a676f661f9',1,'GUJXAXISSDKVersion.h']]],
  ['lib_5fguj_5fxaxis_5fsdk_5fversion',['LIB_GUJ_XAXIS_SDK_VERSION',['../GUJXAXISSDKVersion_8h.html#af72bdb0a510504aabc89bc4adb0f1590',1,'GUJXAXISSDKVersion.h']]],
  ['lib_5fguj_5fxaxis_5fsdk_5fversion_5fcheck',['LIB_GUJ_XAXIS_SDK_VERSION_CHECK',['../GUJXAXISSDKVersion_8h.html#afbdea185f40e9dc5a7f09dd628bf9eb1',1,'GUJXAXISSDKVersion.h']]]
];

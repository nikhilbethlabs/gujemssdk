var searchData=
[
  ['sendadserverrequest',['sendAdServerRequest',['../interfaceGUJXAXSISTrackingServerConnection.html#a201102a423befb887cc437f268466bd7',1,'GUJXAXSISTrackingServerConnection']]],
  ['sendadserverrequestwithreportingadspaceid_3aplacementid_3a',['sendAdServerRequestWithReportingAdSpaceId:placementId:',['../interfaceGUJXAXSISTrackingServerConnection.html#a670baad62a613c1a21875cdba3074c13',1,'GUJXAXSISTrackingServerConnection']]],
  ['setxaxisplacementid_3a',['setXAXISPlacementId:',['../interfaceORMMAXAXISView.html#a19b5be74d9320965ee062c4ad4cdccde',1,'ORMMAXAXISView']]]
];

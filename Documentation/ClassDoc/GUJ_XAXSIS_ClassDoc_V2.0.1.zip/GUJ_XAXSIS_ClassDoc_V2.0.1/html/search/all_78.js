var searchData=
[
  ['xaxisclass_5f',['xaxisClass_',['../interfaceORMMAXAXISView.html#ae2c50465f1491f0015c7414ad86ce0dd',1,'ORMMAXAXISView']]],
  ['xaxisplacementid_5f',['xaxisPlacementId_',['../interfaceORMMAXAXISView.html#a61e110f8f13f464049ee2d9ddeedbed0',1,'ORMMAXAXISView::xaxisPlacementId_()'],['../GUJXAXISViewController_8m.html#a2c0a3d637d0dfafb1501a5ca0472e96f',1,'xaxisPlacementId_():&#160;GUJXAXISViewController.m']]]
];

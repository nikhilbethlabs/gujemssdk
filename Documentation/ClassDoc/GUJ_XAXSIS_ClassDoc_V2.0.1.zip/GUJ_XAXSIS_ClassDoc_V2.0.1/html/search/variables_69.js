var searchData=
[
  ['initialplacementid_5f',['initialPlacementId_',['../interfaceORMMAXAXISView.html#a1788857fd4036e710af8d6bd45eb3cd4',1,'ORMMAXAXISView']]],
  ['isxaxisvideoad_5f',['isXAXISVideoAd_',['../interfaceORMMAXAXISView.html#a5e462506f80b829adfea37e214a5deef',1,'ORMMAXAXISView']]]
];

var searchData=
[
  ['nsobject_2dp',['NSObject-p',['../classNSObject-p.html',1,'']]]
];

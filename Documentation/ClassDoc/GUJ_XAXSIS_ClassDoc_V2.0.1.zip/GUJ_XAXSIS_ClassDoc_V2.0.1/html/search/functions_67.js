var searchData=
[
  ['getxaxisplacementid',['getXAXISPlacementId',['../interfaceORMMAXAXISView.html#abd9fb0b5de034060ab8aa0896f72bc2f',1,'ORMMAXAXISView']]]
];

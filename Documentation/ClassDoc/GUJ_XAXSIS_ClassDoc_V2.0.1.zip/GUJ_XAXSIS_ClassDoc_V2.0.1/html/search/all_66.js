var searchData=
[
  ['freeinstance',['freeInstance',['../interfaceGUJXAXISViewController.html#a8e6ea704978ab1fd528a275214e3dca4',1,'GUJXAXISViewController']]]
];

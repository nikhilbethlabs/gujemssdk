var interfaceGUJXAXSISTrackingServerConnection =
[
    [ "__formattedDateForReporting", "interfaceGUJXAXSISTrackingServerConnection.html#abef8ffe13b178b058d3ab832162a6076", null ],
    [ "sendAdServerRequest", "interfaceGUJXAXSISTrackingServerConnection.html#a201102a423befb887cc437f268466bd7", null ],
    [ "sendAdServerRequestWithReportingAdSpaceId:placementId:", "interfaceGUJXAXSISTrackingServerConnection.html#a670baad62a613c1a21875cdba3074c13", null ]
];
var files =
[
    [ "GUJXAXISConstants.h", "GUJXAXISConstants_8h.html", "GUJXAXISConstants_8h" ],
    [ "GUJXAXISSDKVersion.h", "GUJXAXISSDKVersion_8h.html", "GUJXAXISSDKVersion_8h" ],
    [ "Debug-iphoneos/GUJXAXISSDK.build/Objects-normal/armv7/GUJXAXISViewController.d", "Debug-iphoneos_2GUJXAXISSDK_8build_2Objects-normal_2armv7_2GUJXAXISViewController_8d.html", null ],
    [ "Debug-iphoneos/GUJXAXISSDK.build/Objects-normal/armv7s/GUJXAXISViewController.d", "Debug-iphoneos_2GUJXAXISSDK_8build_2Objects-normal_2armv7s_2GUJXAXISViewController_8d.html", null ],
    [ "Debug-iphonesimulator/GUJXAXISSDKSimulator.build/Objects-normal/i386/GUJXAXISViewController.d", "Debug-iphonesimulator_2GUJXAXISSDKSimulator_8build_2Objects-normal_2i386_2GUJXAXISViewController_8d.html", null ],
    [ "Release-iphoneos/GUJXAXISSDK.build/Objects-normal/armv7/GUJXAXISViewController.d", "Release-iphoneos_2GUJXAXISSDK_8build_2Objects-normal_2armv7_2GUJXAXISViewController_8d.html", null ],
    [ "Release-iphoneos/GUJXAXISSDK.build/Objects-normal/armv7s/GUJXAXISViewController.d", "Release-iphoneos_2GUJXAXISSDK_8build_2Objects-normal_2armv7s_2GUJXAXISViewController_8d.html", null ],
    [ "Release-iphonesimulator/GUJXAXISSDKSimulator.build/Objects-normal/i386/GUJXAXISViewController.d", "Release-iphonesimulator_2GUJXAXISSDKSimulator_8build_2Objects-normal_2i386_2GUJXAXISViewController_8d.html", null ],
    [ "build/Debug-iphoneos/GUJXAXISViewController.h", "build_2Debug-iphoneos_2GUJXAXISViewController_8h.html", [
      [ "GUJXAXISViewController", "interfaceGUJXAXISViewController.html", "interfaceGUJXAXISViewController" ]
    ] ],
    [ "build/Debug-iphoneos/usr/local/include/GUJXAXISViewController.h", "build_2Debug-iphoneos_2usr_2local_2include_2GUJXAXISViewController_8h.html", [
      [ "GUJXAXISViewController", "interfaceGUJXAXISViewController.html", "interfaceGUJXAXISViewController" ]
    ] ],
    [ "build/Debug-iphonesimulator/GUJXAXISViewController.h", "build_2Debug-iphonesimulator_2GUJXAXISViewController_8h.html", [
      [ "GUJXAXISViewController", "interfaceGUJXAXISViewController.html", "interfaceGUJXAXISViewController" ]
    ] ],
    [ "build/Debug-iphonesimulator/usr/local/include/GUJXAXISViewController.h", "build_2Debug-iphonesimulator_2usr_2local_2include_2GUJXAXISViewController_8h.html", [
      [ "GUJXAXISViewController", "interfaceGUJXAXISViewController.html", "interfaceGUJXAXISViewController" ]
    ] ],
    [ "build/Release-iphoneos/GUJXAXISViewController.h", "build_2Release-iphoneos_2GUJXAXISViewController_8h.html", [
      [ "GUJXAXISViewController", "interfaceGUJXAXISViewController.html", "interfaceGUJXAXISViewController" ]
    ] ],
    [ "build/Release-iphoneos/usr/local/include/GUJXAXISViewController.h", "build_2Release-iphoneos_2usr_2local_2include_2GUJXAXISViewController_8h.html", [
      [ "GUJXAXISViewController", "interfaceGUJXAXISViewController.html", "interfaceGUJXAXISViewController" ]
    ] ],
    [ "build/Release-iphonesimulator/GUJXAXISViewController.h", "build_2Release-iphonesimulator_2GUJXAXISViewController_8h.html", [
      [ "GUJXAXISViewController", "interfaceGUJXAXISViewController.html", "interfaceGUJXAXISViewController" ]
    ] ],
    [ "build/Release-iphonesimulator/usr/local/include/GUJXAXISViewController.h", "build_2Release-iphonesimulator_2usr_2local_2include_2GUJXAXISViewController_8h.html", [
      [ "GUJXAXISViewController", "interfaceGUJXAXISViewController.html", "interfaceGUJXAXISViewController" ]
    ] ],
    [ "GUJXAXISSDK/Classes/Public/GUJXAXISViewController.h", "GUJXAXISSDK_2Classes_2Public_2GUJXAXISViewController_8h.html", [
      [ "GUJXAXISViewController", "interfaceGUJXAXISViewController.html", "interfaceGUJXAXISViewController" ]
    ] ],
    [ "GUJXAXISViewController.m", "GUJXAXISViewController_8m.html", "GUJXAXISViewController_8m" ],
    [ "Debug-iphoneos/GUJXAXISSDK.build/Objects-normal/armv7/GUJXAXSISTrackingServerConnection.d", "Debug-iphoneos_2GUJXAXISSDK_8build_2Objects-normal_2armv7_2GUJXAXSISTrackingServerConnection_8d.html", null ],
    [ "Debug-iphoneos/GUJXAXISSDK.build/Objects-normal/armv7s/GUJXAXSISTrackingServerConnection.d", "Debug-iphoneos_2GUJXAXISSDK_8build_2Objects-normal_2armv7s_2GUJXAXSISTrackingServerConnection_8d.html", null ],
    [ "Debug-iphonesimulator/GUJXAXISSDKSimulator.build/Objects-normal/i386/GUJXAXSISTrackingServerConnection.d", "Debug-iphonesimulator_2GUJXAXISSDKSimulator_8build_2Objects-normal_2i386_2GUJXAXSISTrackingServerConnection_8d.html", null ],
    [ "Release-iphoneos/GUJXAXISSDK.build/Objects-normal/armv7/GUJXAXSISTrackingServerConnection.d", "Release-iphoneos_2GUJXAXISSDK_8build_2Objects-normal_2armv7_2GUJXAXSISTrackingServerConnection_8d.html", null ],
    [ "Release-iphoneos/GUJXAXISSDK.build/Objects-normal/armv7s/GUJXAXSISTrackingServerConnection.d", "Release-iphoneos_2GUJXAXISSDK_8build_2Objects-normal_2armv7s_2GUJXAXSISTrackingServerConnection_8d.html", null ],
    [ "Release-iphonesimulator/GUJXAXISSDKSimulator.build/Objects-normal/i386/GUJXAXSISTrackingServerConnection.d", "Release-iphonesimulator_2GUJXAXISSDKSimulator_8build_2Objects-normal_2i386_2GUJXAXSISTrackingServerConnection_8d.html", null ],
    [ "GUJXAXSISTrackingServerConnection.h", "GUJXAXSISTrackingServerConnection_8h.html", [
      [ "GUJXAXSISTrackingServerConnection", "interfaceGUJXAXSISTrackingServerConnection.html", "interfaceGUJXAXSISTrackingServerConnection" ]
    ] ],
    [ "GUJXAXSISTrackingServerConnection.m", "GUJXAXSISTrackingServerConnection_8m.html", null ],
    [ "Debug-iphoneos/GUJXAXISSDK.build/Objects-normal/armv7/ORMMAXAXISView.d", "Debug-iphoneos_2GUJXAXISSDK_8build_2Objects-normal_2armv7_2ORMMAXAXISView_8d.html", null ],
    [ "Debug-iphoneos/GUJXAXISSDK.build/Objects-normal/armv7s/ORMMAXAXISView.d", "Debug-iphoneos_2GUJXAXISSDK_8build_2Objects-normal_2armv7s_2ORMMAXAXISView_8d.html", null ],
    [ "Debug-iphonesimulator/GUJXAXISSDKSimulator.build/Objects-normal/i386/ORMMAXAXISView.d", "Debug-iphonesimulator_2GUJXAXISSDKSimulator_8build_2Objects-normal_2i386_2ORMMAXAXISView_8d.html", null ],
    [ "Release-iphoneos/GUJXAXISSDK.build/Objects-normal/armv7/ORMMAXAXISView.d", "Release-iphoneos_2GUJXAXISSDK_8build_2Objects-normal_2armv7_2ORMMAXAXISView_8d.html", null ],
    [ "Release-iphoneos/GUJXAXISSDK.build/Objects-normal/armv7s/ORMMAXAXISView.d", "Release-iphoneos_2GUJXAXISSDK_8build_2Objects-normal_2armv7s_2ORMMAXAXISView_8d.html", null ],
    [ "Release-iphonesimulator/GUJXAXISSDKSimulator.build/Objects-normal/i386/ORMMAXAXISView.d", "Release-iphonesimulator_2GUJXAXISSDKSimulator_8build_2Objects-normal_2i386_2ORMMAXAXISView_8d.html", null ],
    [ "ORMMAXAXISView.h", "ORMMAXAXISView_8h.html", [
      [ "ORMMAXAXISView", "interfaceORMMAXAXISView.html", "interfaceORMMAXAXISView" ]
    ] ],
    [ "ORMMAXAXISView.m", "ORMMAXAXISView_8m.html", [
      [ "ORMMAXAXISView(PrivateImplementation)", "categoryORMMAXAXISView_07PrivateImplementation_08.html", "categoryORMMAXAXISView_07PrivateImplementation_08" ]
    ] ]
];
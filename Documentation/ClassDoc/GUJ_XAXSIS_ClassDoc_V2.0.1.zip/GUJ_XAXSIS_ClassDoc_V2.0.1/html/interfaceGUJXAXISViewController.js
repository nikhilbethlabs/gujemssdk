var interfaceGUJXAXISViewController =
[
    [ "__setXAXISPlacementId:", "interfaceGUJXAXISViewController.html#a844666e6c389322fc7e5d01e7e5785ae", null ],
    [ "adViewForType:frame:", "interfaceGUJXAXISViewController.html#af6b253af2ac1b942138d14e17e151bdf", null ],
    [ "freeInstance", "interfaceGUJXAXISViewController.html#a8e6ea704978ab1fd528a275214e3dca4", null ],
    [ "instanceForAdspaceId:", "interfaceGUJXAXISViewController.html#a6c8e92112e218dc87034b1485ee7a092", null ],
    [ "instanceForAdspaceId:delegate:", "interfaceGUJXAXISViewController.html#a6974fe472e5e27a7bce0ca9dd31cf3ba", null ],
    [ "instanceForAdspaceId:site:zone:", "interfaceGUJXAXISViewController.html#abd9d4e053197af8ace3f202a521bd2f3", null ],
    [ "instanceForAdspaceId:site:zone:delegate:", "interfaceGUJXAXISViewController.html#acfcc0b46c55bf62788455a6bac747593", null ]
];
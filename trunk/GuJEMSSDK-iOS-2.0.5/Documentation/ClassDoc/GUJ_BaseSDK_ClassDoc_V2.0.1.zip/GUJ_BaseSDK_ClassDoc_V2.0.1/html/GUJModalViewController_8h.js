var GUJModalViewController_8h =
[
    [ "<GUJModalViewControllerDelegate>", "protocolGUJModalViewControllerDelegate-p.html", "protocolGUJModalViewControllerDelegate-p" ],
    [ "GUJModalViewController", "interfaceGUJModalViewController.html", "interfaceGUJModalViewController" ],
    [ "kGUJModalViewControllerCloseBoxImage", "GUJModalViewController_8h.html#a213a6c3064db59d53fed0f92cc933539", null ]
];
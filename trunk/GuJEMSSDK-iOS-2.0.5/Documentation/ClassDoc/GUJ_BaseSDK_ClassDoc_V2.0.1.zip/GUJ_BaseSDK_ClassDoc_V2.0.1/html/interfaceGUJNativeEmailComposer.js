var interfaceGUJNativeEmailComposer =
[
    [ "canComposeEmail", "interfaceGUJNativeEmailComposer.html#a04b3c783ae061cd81eb716bb27827de2", null ],
    [ "composeEmailTo:subject:body:", "interfaceGUJNativeEmailComposer.html#a4d476d869bcdef5412fb2a9d5ee867a8", null ],
    [ "init", "interfaceGUJNativeEmailComposer.html#a2ef43c533e4566bef0260e1632408596", null ],
    [ "mailComposeController:didFinishWithResult:error:", "interfaceGUJNativeEmailComposer.html#ad60efd662c7e8bcc1a2dbfe854e124e3", null ],
    [ "isHTMLContent", "interfaceGUJNativeEmailComposer.html#a777aebc6aa821350cf9b01f698bb021d", null ],
    [ "mailComposeVC", "interfaceGUJNativeEmailComposer.html#a42a327cb740e1fd48852201f727ab7bd", null ]
];
var protocolGUJModalViewControllerDelegate_p =
[
    [ "modalViewControllerDidAppear:", "protocolGUJModalViewControllerDelegate-p.html#ad66d5b352f2c9c978a7e69bddf7cff03", null ],
    [ "modalViewControllerDidDisappear", "protocolGUJModalViewControllerDelegate-p.html#a66dafc43031c5b5618db3a570da1fbb7", null ],
    [ "modalViewControllerWillAppear", "protocolGUJModalViewControllerDelegate-p.html#a4e62f40b4abe0cad3c55a5e13d03e27a", null ],
    [ "modalViewControllerWillDisappear:", "protocolGUJModalViewControllerDelegate-p.html#ac294e6195b484582a1bcf22d426035ad", null ]
];
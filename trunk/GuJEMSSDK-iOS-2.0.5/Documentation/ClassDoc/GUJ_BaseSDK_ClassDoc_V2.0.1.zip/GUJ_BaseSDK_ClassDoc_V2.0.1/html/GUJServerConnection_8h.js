var GUJServerConnection_8h =
[
    [ "GUJServerConnection(Private)", "categoryGUJServerConnection_07Private_08.html", "categoryGUJServerConnection_07Private_08" ],
    [ "adServerRequestWithConfiguration:completion:", "GUJServerConnection_8h.html#a788d5e14fb31ca179d684278ed95bac1", null ],
    [ "initWithAdConfiguration:", "GUJServerConnection_8h.html#a2b42132898379037759b7bfbaed9e7a9", null ],
    [ "sendAdServerRequest:", "GUJServerConnection_8h.html#aa9cfcd96d0e08516d2be9e8356acdbca", null ],
    [ "adConfiguration", "GUJServerConnection_8h.html#a6709813442d7e083ed59d6c008f97475", null ],
    [ "adData", "GUJServerConnection_8h.html#a11813ac95b0e08abbea13a11f51a36e7", null ],
    [ "error", "GUJServerConnection_8h.html#aa4a96b60b18f49477d1c840bb272eceb", null ],
    [ "httpHeaderFields", "GUJServerConnection_8h.html#a9ae1e51f0726d15ba7dba39b27357dd0", null ],
    [ "request", "GUJServerConnection_8h.html#a60dc29c4a950a68e0bd3ec119ca89923", null ],
    [ "response", "GUJServerConnection_8h.html#ac15820ab39263224bcd0094406f19067", null ],
    [ "url", "GUJServerConnection_8h.html#ac22936aba8881c3f0d01de61417c85c7", null ]
];
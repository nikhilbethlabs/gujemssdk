var categoryGUJNativeAPIInterface_07Private_08 =
[
    [ "__setRequiredDeviceCapability:", "categoryGUJNativeAPIInterface_07Private_08.html#a859025ef59420891cd420a641e74e399", null ]
];
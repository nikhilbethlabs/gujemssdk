var interfaceGUJNativeKeyboardObserver =
[
    [ "__startKeyboardObserver", "interfaceGUJNativeKeyboardObserver.html#a7c3ee0b0aeb61b235d0f9c23c7300386", null ],
    [ "__stopKeyboardObserver", "interfaceGUJNativeKeyboardObserver.html#a39d4f8d6ffd3007680c59505cd441808", null ],
    [ "freeInstance", "interfaceGUJNativeKeyboardObserver.html#a1486dac2cd1635f2462e0cfed2317f71", null ],
    [ "isObserver", "interfaceGUJNativeKeyboardObserver.html#a33e58dcbc5cc48c74e78829ae9ad9d0e", null ],
    [ "keyboardChangedNotification:", "interfaceGUJNativeKeyboardObserver.html#a65fab1d2cd6507f77604812b0d001a1f", null ],
    [ "sharedInstance", "interfaceGUJNativeKeyboardObserver.html#a66fed3ebeb5f9e1ed4eb19a76bf33336", null ],
    [ "startObserver", "interfaceGUJNativeKeyboardObserver.html#ad822194107ef2a9967ac3fe3fc2e7183", null ],
    [ "stopObserver", "interfaceGUJNativeKeyboardObserver.html#ad5b91442bf5f8fe898dada37e01e7108", null ],
    [ "willPostNotification", "interfaceGUJNativeKeyboardObserver.html#a2ffd32144437d61f8232d24424d09ce4", null ],
    [ "keyboardIsVidible", "interfaceGUJNativeKeyboardObserver.html#aeba65fe8277c4a377c995367eb63fff4", null ]
];
var interfaceGUJObserver =
[
    [ "startObserver", "interfaceGUJObserver.html#a7aa7d4a718f9b4a9687ca539f9a38222", null ],
    [ "startObserverWithNotificationReceiver:selector:", "interfaceGUJObserver.html#abd00653926b0782f5644e0614e956b31", null ],
    [ "stopObserver", "interfaceGUJObserver.html#a6de05f1712a4414578777e47a6ea27fe", null ],
    [ "stopObserverWithNotificationReceiver:", "interfaceGUJObserver.html#acf75a22748edad6ca7e0a8c8c815f16c", null ]
];
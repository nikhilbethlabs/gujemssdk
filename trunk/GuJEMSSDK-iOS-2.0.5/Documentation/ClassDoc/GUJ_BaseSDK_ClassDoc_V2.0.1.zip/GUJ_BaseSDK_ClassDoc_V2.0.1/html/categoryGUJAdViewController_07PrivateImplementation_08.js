var categoryGUJAdViewController_07PrivateImplementation_08 =
[
    [ "adViewForType:frame:", "categoryGUJAdViewController_07PrivateImplementation_08.html#a211d687cc8cd9bcda7d947ab01feaba9", null ],
    [ "initializeNativeInterfaces", "categoryGUJAdViewController_07PrivateImplementation_08.html#a1ea9f2cdfeee9a7e839a53d872c8f760", null ],
    [ "instanciate", "categoryGUJAdViewController_07PrivateImplementation_08.html#adcdc3db4665b15717cf31f4dea445d2a", null ],
    [ "populateAdView:", "categoryGUJAdViewController_07PrivateImplementation_08.html#aec65e879ea780ff6e12a3306b84622fd", null ]
];
var interfaceGUJAdData =
[
    [ "asNSUTF8StringRepresentation", "interfaceGUJAdData.html#a8ceae000e832b3226de5a62efe38b3a0", null ],
    [ "bytes", "interfaceGUJAdData.html#a5123fe7f28683fdf3f8236a45c987e00", null ],
    [ "dataWithData:", "interfaceGUJAdData.html#ada17046a4fa91d8e2b2ad0b88e43d713", null ],
    [ "length", "interfaceGUJAdData.html#a3688941a3891da76cda359c91104967e", null ],
    [ "mutableBytes", "interfaceGUJAdData.html#a8288cedbce79eb684320eb7908e2dd1d", null ],
    [ "setData:", "interfaceGUJAdData.html#a0158555626efd91ba9b6117501531545", null ],
    [ "setLength:", "interfaceGUJAdData.html#ac106e9502256e6f47e3e8d66ce07dab5", null ],
    [ "_length", "interfaceGUJAdData.html#acf2a7817339ee0f9d0622063a8470eab", null ]
];
var interfaceGUJNativePhoneCall =
[
    [ "freeInstance", "interfaceGUJNativePhoneCall.html#a4eb1f0e6d3a1dddc66bdff99e2549ecb", null ],
    [ "init", "interfaceGUJNativePhoneCall.html#a3c590a883a01eb55d378c8f4ec5f76fc", null ],
    [ "initializePhoneCall:", "interfaceGUJNativePhoneCall.html#a36363f978a80f12da14f1ffeae1cb1b6", null ],
    [ "isAvailableForCurrentDevice", "interfaceGUJNativePhoneCall.html#a4b9188d08e07da5489ce3c0d2befd876", null ],
    [ "promptForPhoneCall:", "interfaceGUJNativePhoneCall.html#a323aaa128e39ca371d41ecda538f7609", null ]
];
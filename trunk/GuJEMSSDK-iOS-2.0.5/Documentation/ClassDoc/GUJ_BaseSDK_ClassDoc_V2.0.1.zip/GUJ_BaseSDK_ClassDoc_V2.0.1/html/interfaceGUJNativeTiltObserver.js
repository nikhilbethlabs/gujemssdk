var interfaceGUJNativeTiltObserver =
[
    [ "__enableAccelerometer", "interfaceGUJNativeTiltObserver.html#afedbb971331745a88f7aee139997e598", null ],
    [ "__startTiltObserver", "interfaceGUJNativeTiltObserver.html#ab4cae6b07db06d53547b75369e752990", null ],
    [ "__stopTiltObserver", "interfaceGUJNativeTiltObserver.html#a136f6e7bcc09bd302cd773eddb35ba1d", null ],
    [ "__testForAccelerometerEvent:threshold:", "interfaceGUJNativeTiltObserver.html#a61e381408b237ad30838fe85af843df4", null ],
    [ "__testForTiltEvent:", "interfaceGUJNativeTiltObserver.html#a7e438aa489ec7363fe21d9a696d43cce", null ],
    [ "accelerometer:didAccelerate:", "interfaceGUJNativeTiltObserver.html#a8f65e4b47a48cede4aee737a9d8d720f", null ],
    [ "freeInstance", "interfaceGUJNativeTiltObserver.html#a2e36fc072a82dcefe8b2a8dfb729d860", null ],
    [ "init", "interfaceGUJNativeTiltObserver.html#aa19fa54f8ec238be9b288ddc19f1f89e", null ],
    [ "isAvailableForCurrentDevice", "interfaceGUJNativeTiltObserver.html#a758596b26ffff29ad2ebb7e2df9a18e4", null ],
    [ "isObserver", "interfaceGUJNativeTiltObserver.html#a82816aeee297085741accba8e9609594", null ],
    [ "sharedInstance", "interfaceGUJNativeTiltObserver.html#ac535a92b35f034bd225ab94164aba5e3", null ],
    [ "startObserver", "interfaceGUJNativeTiltObserver.html#a4f1486ad25a0d8f5800ede6f9a13bb8b", null ],
    [ "stopObserver", "interfaceGUJNativeTiltObserver.html#a3e3337a7b1900a18bda7914d4601426d", null ],
    [ "willPostNotification", "interfaceGUJNativeTiltObserver.html#a1c6572bb82e4af38ba979c9ee6ff2d74", null ],
    [ "acceleration", "interfaceGUJNativeTiltObserver.html#a9d92546441f8bb7076f6f645c6277b67", null ],
    [ "accelerometerEnabled", "interfaceGUJNativeTiltObserver.html#afd68b0f4406ddd4dacff82d9b0ec408a", null ],
    [ "lastAcceleration", "interfaceGUJNativeTiltObserver.html#a674dbbeebbc10286d3c60bdeb1080d1a", null ]
];
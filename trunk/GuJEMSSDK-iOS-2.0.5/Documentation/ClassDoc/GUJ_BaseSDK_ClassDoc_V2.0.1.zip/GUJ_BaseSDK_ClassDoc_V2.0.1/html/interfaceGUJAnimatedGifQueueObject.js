var interfaceGUJAnimatedGifQueueObject =
[
    [ "uiv", "interfaceGUJAnimatedGifQueueObject.html#a7c72be9ce69cc001f1b104fce8b0a5ee", null ],
    [ "url", "interfaceGUJAnimatedGifQueueObject.html#a07a3d86b2c0b901bf70395aec0322c11", null ]
];
var interfaceGUJNativeOrientationManager =
[
    [ "__startOrientationObserver", "interfaceGUJNativeOrientationManager.html#af2936f1a9d34a2cbe5af4dcd5864f8b5", null ],
    [ "__stopOrientationObserver", "interfaceGUJNativeOrientationManager.html#a8b322432ee3c5d3df33e9995bdcfcab0", null ],
    [ "freeInstance", "interfaceGUJNativeOrientationManager.html#ac9cf46737ec7c63f500827b7fa6518e2", null ],
    [ "isObserver", "interfaceGUJNativeOrientationManager.html#a60c84ee486e792661db19ffefbc0f25c", null ],
    [ "orientationChangedNotification:", "interfaceGUJNativeOrientationManager.html#ae3df2e25b4370ca97d20c9ba800f3cbf", null ],
    [ "sharedInstance", "interfaceGUJNativeOrientationManager.html#a17e20161fc89e4f9a0b0d3835845ef2f", null ],
    [ "startObserver", "interfaceGUJNativeOrientationManager.html#aa4c8cf5d05a8b7ebd4699f732b4f9315", null ],
    [ "stopObserver", "interfaceGUJNativeOrientationManager.html#af85465a8a4da13e4128cfb5cc18b1c93", null ],
    [ "willPostNotification", "interfaceGUJNativeOrientationManager.html#aae71a9216b122ff4c7c53731f9f41846", null ],
    [ "deviceOrientation", "interfaceGUJNativeOrientationManager.html#a3dc9933cf0d58026aadb3ee4b5d43151", null ]
];
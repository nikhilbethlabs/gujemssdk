var interfaceGUJModalViewController =
[
    [ "__createUI", "interfaceGUJModalViewController.html#a9827333ea6bbd159401ec19c630d704e", null ],
    [ "__dismissSelf", "interfaceGUJModalViewController.html#a55e388a90d474a1f76afa4981c6bc6ed", null ],
    [ "addSubviewInset:", "interfaceGUJModalViewController.html#ab1d4649c854e9bcc1c4d0342ee3fce7c", null ],
    [ "dismiss", "interfaceGUJModalViewController.html#aa8e5bb2e2fe1b5e5d102f044d9d27f47", null ],
    [ "dismiss:", "interfaceGUJModalViewController.html#a47965e8155082b98281d7cac4e4cabdb", null ],
    [ "hideCloseButton:", "interfaceGUJModalViewController.html#a84939111fab681f086c47e8573269e7f", null ],
    [ "initWithNibName:bundle:", "interfaceGUJModalViewController.html#a5b1a96098d684a1148caa37f309dc8b6", null ],
    [ "viewDidAppear:", "interfaceGUJModalViewController.html#a5f7eb594146127bc5691f616b5805cc0", null ],
    [ "viewDidDisappear:", "interfaceGUJModalViewController.html#a982a92a4e77ba27f9b24e8c694f7ad1e", null ],
    [ "viewDidLoad", "interfaceGUJModalViewController.html#a74496b53295a21f3cb396bd7498eed14", null ],
    [ "viewWillAppear:", "interfaceGUJModalViewController.html#ace3d4f5c61267e814bc94c38d2be04ca", null ],
    [ "viewWillDisappear:", "interfaceGUJModalViewController.html#a9014ad4426065dbf374d54285b9ad73c", null ],
    [ "closeButton", "interfaceGUJModalViewController.html#a0f86e154c144db41466ee416d599b44e", null ],
    [ "closeButtonImage", "interfaceGUJModalViewController.html#a1c708e590d05e5aa37f064dcffacb124", null ],
    [ "defaultStatusBarState", "interfaceGUJModalViewController.html#a21472926eb8fe6cd6caf8d223e73baf3", null ],
    [ "delegate", "interfaceGUJModalViewController.html#a04101abadcb3f5b56b82335f026ba983", null ]
];
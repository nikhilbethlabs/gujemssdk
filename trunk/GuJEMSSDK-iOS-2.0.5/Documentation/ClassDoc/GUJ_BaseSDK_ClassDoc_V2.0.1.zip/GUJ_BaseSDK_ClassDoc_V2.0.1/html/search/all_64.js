var searchData=
[
  ['datapointer',['dataPointer',['../interfaceGUJAnimatedGif.html#aed0aad55cd87b04bbf18b6fbc20f8258',1,'GUJAnimatedGif']]],
  ['datawithdata_3a',['dataWithData:',['../interfaceGUJAdData.html#ada17046a4fa91d8e2b2ad0b88e43d713',1,'GUJAdData']]],
  ['decodegif_3a',['decodeGIF:',['../interfaceGUJAnimatedGif.html#a72a5dcfeacb9bdc43f809db62714ce27',1,'GUJAnimatedGif']]],
  ['defaultstatusbarstate',['defaultStatusBarState',['../interfaceGUJModalViewController.html#a21472926eb8fe6cd6caf8d223e73baf3',1,'GUJModalViewController']]],
  ['delegate',['delegate',['../interface__GUJAdView.html#acadfeb050946473fd0cb138d7c995416',1,'_GUJAdView::delegate()'],['../interfaceGUJModalViewController.html#a04101abadcb3f5b56b82335f026ba983',1,'GUJModalViewController::delegate()'],['../interfaceGUJAdViewController.html#a5401f7ea817d141a7ad04d0c17032053',1,'GUJAdViewController::delegate()']]],
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]],
  ['devicecapabilities',['deviceCapabilities',['../interfaceGUJDeviceCapabilities.html#abff819aba5a9bbd55b324e6c436eac7a',1,'GUJDeviceCapabilities']]],
  ['devicemodel',['deviceModel',['../classGUJUtil.html#a0ea1e939fd59811f81308eee5f7989e8',1,'GUJUtil']]],
  ['deviceorientation',['deviceOrientation',['../interfaceGUJNativeOrientationManager.html#a3dc9933cf0d58026aadb3ee4b5d43151',1,'GUJNativeOrientationManager']]],
  ['devicesupportscapability_3a',['deviceSupportsCapability:',['../interfaceGUJDeviceCapabilities.html#aed1227ee183d403be3f1089b58977a04',1,'GUJDeviceCapabilities']]],
  ['disablelocationservice',['disableLocationService',['../interfaceGUJAdViewController.html#a40c05bdd560915410778070540eca5e5',1,'GUJAdViewController']]],
  ['dismiss',['dismiss',['../interfaceGUJModalViewController.html#aa8e5bb2e2fe1b5e5d102f044d9d27f47',1,'GUJModalViewController']]],
  ['dismiss_3a',['dismiss:',['../interfaceGUJModalViewController.html#a47965e8155082b98281d7cac4e4cabdb',1,'GUJModalViewController']]]
];

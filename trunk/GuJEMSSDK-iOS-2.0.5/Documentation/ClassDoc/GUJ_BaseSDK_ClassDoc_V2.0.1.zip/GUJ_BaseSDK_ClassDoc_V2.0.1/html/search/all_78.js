var searchData=
[
  ['xmlns',['xmlns',['../interfaceGUJBannerXMLParser.html#a7f10561ac58af8190302b7d5ef83533f',1,'GUJBannerXMLParser']]],
  ['xmlns_5f',['xmlns_',['../interfaceGUJBannerXMLParser.html#a9e652b03e77876b5959c53a90d17c6b8',1,'GUJBannerXMLParser']]]
];

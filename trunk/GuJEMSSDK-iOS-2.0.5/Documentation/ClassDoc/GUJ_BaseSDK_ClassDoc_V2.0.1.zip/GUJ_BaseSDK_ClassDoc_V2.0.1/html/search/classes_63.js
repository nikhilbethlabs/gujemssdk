var searchData=
[
  ['cllocationmanagerdelegate_2dp',['CLLocationManagerDelegate-p',['../classCLLocationManagerDelegate-p.html',1,'']]]
];

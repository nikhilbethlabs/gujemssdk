var GUJNativeKeyboardObserver_8m =
[
    [ "sharedInstance_", "GUJNativeKeyboardObserver_8m.html#aea728d289ac375f43778f0c58321d773", null ]
];
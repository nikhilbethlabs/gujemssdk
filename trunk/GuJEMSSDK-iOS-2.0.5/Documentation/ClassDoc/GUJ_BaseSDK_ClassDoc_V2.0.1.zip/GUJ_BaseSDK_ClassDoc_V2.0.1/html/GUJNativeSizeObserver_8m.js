var GUJNativeSizeObserver_8m =
[
    [ "sharedInstance_", "GUJNativeSizeObserver_8m.html#a6e71df6f225021c0f14cca8cc04aac23", null ]
];
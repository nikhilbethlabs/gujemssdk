var GUJBaseSDKVersion_8h =
[
    [ "LIB_GUJ_BASE_SDK_MAJOR_VERSION", "GUJBaseSDKVersion_8h.html#aebace1c037d12cd8e3d09e594822bf14", null ],
    [ "LIB_GUJ_BASE_SDK_MINOR_VERSION", "GUJBaseSDKVersion_8h.html#a351546426dd26cb76d146ebc9fc73c5d", null ],
    [ "LIB_GUJ_BASE_SDK_REVISION", "GUJBaseSDKVersion_8h.html#ac8458f7958b0a7a24d7906c4ff8ee726", null ],
    [ "LIB_GUJ_BASE_SDK_VERSION", "GUJBaseSDKVersion_8h.html#a70c626b81e042d59014bb038dc5d59ad", null ],
    [ "LIB_GUJ_BASE_SDK_VERSION_CHECK", "GUJBaseSDKVersion_8h.html#aaa86c072424e0fe43c3a0a90813880c9", null ]
];
var interfaceGUJDeviceCapabilities =
[
    [ "__canLoadClass:", "interfaceGUJDeviceCapabilities.html#afcc8dd77a466f8d0b2c25facc02da66b", null ],
    [ "__loadClass:", "interfaceGUJDeviceCapabilities.html#a6fd2ef8131e2e77303fdac755144cfeb", null ],
    [ "deviceCapabilities", "interfaceGUJDeviceCapabilities.html#abff819aba5a9bbd55b324e6c436eac7a", null ],
    [ "deviceSupportsCapability:", "interfaceGUJDeviceCapabilities.html#aed1227ee183d403be3f1089b58977a04", null ],
    [ "freeInstance", "interfaceGUJDeviceCapabilities.html#a218fdfa841f7e9a1c447d57148e2386e", null ],
    [ "nativeClassInstanceForCapability:", "interfaceGUJDeviceCapabilities.html#a75f655dd1addedcc0b8b960847c29bc9", null ],
    [ "sharedInstance", "interfaceGUJDeviceCapabilities.html#a44023a9249c5af86d30546111db9e850", null ],
    [ "systemClassForCapability:", "interfaceGUJDeviceCapabilities.html#af7dde7b740b603f47497e136f680b6f0", null ]
];
var interfaceGUJNativeCamera =
[
    [ "freeInstance", "interfaceGUJNativeCamera.html#a3ae58427467f2366100f2f7a0afff676", null ],
    [ "hasCameraImage", "interfaceGUJNativeCamera.html#a7c8066fa8ad235f0d9000b98190dffaf", null ],
    [ "hasGalleryImage", "interfaceGUJNativeCamera.html#a888ed6e1b211636fb5963f1647cabe50", null ],
    [ "image", "interfaceGUJNativeCamera.html#af152d16da2dd68f9973d783ee1414a3c", null ],
    [ "imagePickerController:didFinishPickingImage:editingInfo:", "interfaceGUJNativeCamera.html#a56ce9ba2577f1be42f0b77ec5611a79d", null ],
    [ "imagePickerControllerDidCancel:", "interfaceGUJNativeCamera.html#a4ba6aede9d5988a8a874d2fd04bf38cd", null ],
    [ "init", "interfaceGUJNativeCamera.html#a636284f96643a9748e94d653099d8412", null ],
    [ "openCamera", "interfaceGUJNativeCamera.html#a70ee0f44985e5272b477574be38fcebf", null ],
    [ "openGallery", "interfaceGUJNativeCamera.html#a11da306b11a5c1a0c10545c5ed8cf915", null ],
    [ "willPostNotification", "interfaceGUJNativeCamera.html#a03bb9d4d50df0aa91d8faacce66089bd", null ],
    [ "currentImage", "interfaceGUJNativeCamera.html#ab767f900e78cb9d34e924f9c9915df71", null ],
    [ "isCameraImage", "interfaceGUJNativeCamera.html#a8b66ff63bd7fbcdc564864df339fae1c", null ],
    [ "isGalleryImage", "interfaceGUJNativeCamera.html#a8ba91a08b3b474a8934600dec66a7d55", null ],
    [ "pickerController", "interfaceGUJNativeCamera.html#a26bbb5504c862adb7684ed41ba52a575", null ]
];
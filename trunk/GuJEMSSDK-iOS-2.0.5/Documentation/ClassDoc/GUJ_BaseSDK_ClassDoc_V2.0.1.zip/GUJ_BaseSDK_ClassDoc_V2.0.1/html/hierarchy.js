var hierarchy =
[
    [ "<CLLocationManagerDelegate>", "classCLLocationManagerDelegate-p.html", [
      [ "GUJNativeLocationManager", "interfaceGUJNativeLocationManager.html", null ]
    ] ],
    [ "GUJAdURLBuilder(Private)", "categoryGUJAdURLBuilder_07Private_08.html", null ],
    [ "GUJAdViewEvent(Private)", "categoryGUJAdViewEvent_07Private_08.html", null ],
    [ "GUJNativeAPIInterface(Private)", "categoryGUJNativeAPIInterface_07Private_08.html", null ],
    [ "GUJNativeLocationManager(Private)", "categoryGUJNativeLocationManager_07Private_08.html", null ],
    [ "GUJServerConnection", "classGUJServerConnection.html", null ],
    [ "GUJServerConnection(Private)", "categoryGUJServerConnection_07Private_08.html", null ],
    [ "GUJUtil", "classGUJUtil.html", null ],
    [ "<MFMailComposeViewControllerDelegate>", "classMFMailComposeViewControllerDelegate-p.html", [
      [ "GUJNativeEmailComposer", "interfaceGUJNativeEmailComposer.html", null ]
    ] ],
    [ "<MFMessageComposeViewControllerDelegate>", "classMFMessageComposeViewControllerDelegate-p.html", [
      [ "GUJNativeSMSComposer", "interfaceGUJNativeSMSComposer.html", null ]
    ] ],
    [ "<MKMapViewDelegate>", "classMKMapViewDelegate-p.html", [
      [ "GUJNativeMapView", "interfaceGUJNativeMapView.html", null ]
    ] ],
    [ "NSMutableData", "classNSMutableData.html", [
      [ "GUJAdData", "interfaceGUJAdData.html", null ]
    ] ],
    [ "NSObject", "classNSObject.html", [
      [ "GUJAdConfiguration", "interfaceGUJAdConfiguration.html", null ],
      [ "GUJAdURLBuilder", "interfaceGUJAdURLBuilder.html", null ],
      [ "GUJAdViewEvent", "classGUJAdViewEvent.html", null ],
      [ "GUJAnimatedGif", "interfaceGUJAnimatedGif.html", null ],
      [ "GUJAnimatedGifQueueObject", "interfaceGUJAnimatedGifQueueObject.html", null ],
      [ "GUJBase64Util", "interfaceGUJBase64Util.html", null ],
      [ "GUJDeviceCapabilities", "interfaceGUJDeviceCapabilities.html", null ],
      [ "GUJGenericAnnotation", "interfaceGUJGenericAnnotation.html", null ],
      [ "GUJObserver", "interfaceGUJObserver.html", [
        [ "GUJNotificationObserver", "interfaceGUJNotificationObserver.html", [
          [ "GUJNativeAPIInterface", "interfaceGUJNativeAPIInterface.html", [
            [ "GUJNativeAudioPlayer", "interfaceGUJNativeAudioPlayer.html", null ],
            [ "GUJNativeCalendar", "interfaceGUJNativeCalendar.html", null ],
            [ "GUJNativeCamera", "interfaceGUJNativeCamera.html", null ],
            [ "GUJNativeEmailComposer", "interfaceGUJNativeEmailComposer.html", null ],
            [ "GUJNativeKeyboardObserver", "interfaceGUJNativeKeyboardObserver.html", null ],
            [ "GUJNativeLocationManager", "interfaceGUJNativeLocationManager.html", null ],
            [ "GUJNativeMapView", "interfaceGUJNativeMapView.html", null ],
            [ "GUJNativeMoviePlayer", "interfaceGUJNativeMoviePlayer.html", null ],
            [ "GUJNativeNetworkObserver", "interfaceGUJNativeNetworkObserver.html", null ],
            [ "GUJNativeOrientationManager", "interfaceGUJNativeOrientationManager.html", null ],
            [ "GUJNativePhoneCall", "interfaceGUJNativePhoneCall.html", null ],
            [ "GUJNativeShakeObserver", "interfaceGUJNativeShakeObserver.html", null ],
            [ "GUJNativeSizeObserver", "interfaceGUJNativeSizeObserver.html", null ],
            [ "GUJNativeSMSComposer", "interfaceGUJNativeSMSComposer.html", null ],
            [ "GUJNativeTiltObserver", "interfaceGUJNativeTiltObserver.html", null ]
          ] ]
        ] ]
      ] ]
    ] ],
    [ "<NSObject>", "classNSObject-p.html", [
      [ "<GUJAdViewControllerDelegate>", "protocolGUJAdViewControllerDelegate-p.html", null ],
      [ "<GUJAdViewDelegate>", "protocolGUJAdViewDelegate-p.html", [
        [ "GUJAdViewController(PrivateImplementation)", "categoryGUJAdViewController_07PrivateImplementation_08.html", null ]
      ] ],
      [ "GUJBannerXMLParser", "interfaceGUJBannerXMLParser.html", null ],
      [ "<GUJModalViewControllerDelegate>", "protocolGUJModalViewControllerDelegate-p.html", null ]
    ] ],
    [ "NSURL", "classNSURL.html", [
      [ "GUJAdURL", "interfaceGUJAdURL.html", null ]
    ] ],
    [ "<NSXMLParserDelegate>", "classNSXMLParserDelegate-p.html", [
      [ "GUJBannerXMLParser", "interfaceGUJBannerXMLParser.html", null ]
    ] ],
    [ "<UIAccelerometerDelegate>", "classUIAccelerometerDelegate-p.html", [
      [ "GUJNativeShakeObserver", "interfaceGUJNativeShakeObserver.html", null ],
      [ "GUJNativeTiltObserver", "interfaceGUJNativeTiltObserver.html", null ]
    ] ],
    [ "<UIApplicationDelegate>", "classUIApplicationDelegate-p.html", [
      [ "<GUJAdViewControllerDelegate>", "protocolGUJAdViewControllerDelegate-p.html", null ]
    ] ],
    [ "<UIImagePickerControllerDelegate>", "classUIImagePickerControllerDelegate-p.html", [
      [ "GUJNativeCamera", "interfaceGUJNativeCamera.html", null ]
    ] ],
    [ "<UINavigationControllerDelegate>", "classUINavigationControllerDelegate-p.html", [
      [ "GUJNativeCamera", "interfaceGUJNativeCamera.html", null ]
    ] ],
    [ "UIView", "classUIView.html", [
      [ "_GUJAdView", "interface__GUJAdView.html", null ],
      [ "GUJAdView", "interfaceGUJAdView.html", null ]
    ] ],
    [ "UIViewController", "classUIViewController.html", [
      [ "GUJAdViewController", "interfaceGUJAdViewController.html", null ],
      [ "GUJModalViewController", "interfaceGUJModalViewController.html", null ]
    ] ]
];
var interfaceGUJAdURL =
[
    [ "addParameter:value:", "interfaceGUJAdURL.html#a2d5f8a3e2550e8f7aaaadcdf7effe8c8", null ],
    [ "replaceParameter:value:", "interfaceGUJAdURL.html#ab025144c916f9027fe6406ad7abb2285", null ],
    [ "URLForType:andMarkupType:configuration:", "interfaceGUJAdURL.html#aab0459d5f4edebca19a431f71dcfdde4", null ],
    [ "URLForType:configuration:", "interfaceGUJAdURL.html#a44d25c88748c9a07a5c2d3f41b0a0476", null ],
    [ "valueForURLParameter:", "interfaceGUJAdURL.html#ac92c1b91f8985d035005a6fee28e3c83", null ],
    [ "urlBuilder", "interfaceGUJAdURL.html#a21ea4e9b6baa7e087c4fcfc17385d7cf", null ]
];
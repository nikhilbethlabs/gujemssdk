var GUJMacros_8h =
[
    [ "IS_IPAD", "GUJMacros_8h.html#a33585d9e115c259569510f3e0b94c3b9", null ],
    [ "IS_IPHONE", "GUJMacros_8h.html#a29d5757750cfceaae8ff035689b17d44", null ],
    [ "NSNUMBER_WITH_BOOL", "GUJMacros_8h.html#a9bca1c3c12ed1bac3b5af20fafa0ebbe", null ],
    [ "NSNUMBER_WITH_DOUBLE", "GUJMacros_8h.html#a92e7f98821b09fa3c000a5755c47f599", null ],
    [ "NSNUMBER_WITH_FLOAT", "GUJMacros_8h.html#ac9c6169158e625f0b74efb65a175e6ed", null ],
    [ "NSNUMBER_WITH_INT", "GUJMacros_8h.html#ad6ff05d493d1cf48ceef81f7f58d2e73", null ],
    [ "NSNUMBER_WITH_LONG", "GUJMacros_8h.html#af41c21945b191d2b744f6ec054b9d1b2", null ],
    [ "NSNUMBER_WITH_LONG_LONG", "GUJMacros_8h.html#a1795a7c716962a5aa0e180367da3017d", null ]
];
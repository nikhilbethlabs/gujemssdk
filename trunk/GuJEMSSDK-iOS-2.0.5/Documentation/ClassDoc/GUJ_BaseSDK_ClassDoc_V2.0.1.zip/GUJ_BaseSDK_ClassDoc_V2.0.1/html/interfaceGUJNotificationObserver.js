var interfaceGUJNotificationObserver =
[
    [ "__rebuildNSInvocationOperation:withNotification:", "interfaceGUJNotificationObserver.html#a0162a4377e453f38e6662dc1853483ae", null ],
    [ "addObserverForNotification:receiver:selector:", "interfaceGUJNotificationObserver.html#a77480ede4c223f524e8627f4ab7ebbe9", null ],
    [ "addObserverForNotification:sender:receiver:selector:", "interfaceGUJNotificationObserver.html#a707985ae61d3c08920816353f8bc246a", null ],
    [ "freeInstance", "interfaceGUJNotificationObserver.html#adc49fc655417f66c044c8832e20844ba", null ],
    [ "removeFromNotificationQueue:", "interfaceGUJNotificationObserver.html#a9ba4f640f3d238cee72a71644c40b167", null ],
    [ "removeObserverForAllNotifications:", "interfaceGUJNotificationObserver.html#a2ce5c1d50463a6318437fc35d6bc26b0", null ],
    [ "removeObserverForNotification:receiver:", "interfaceGUJNotificationObserver.html#ab76e9101853a4d604480bff9a5bc4c7a", null ],
    [ "removeObserverForNotification:sender:receiver:", "interfaceGUJNotificationObserver.html#a1ba094498da7eb122bf5481e4e768f52", null ],
    [ "handledNotifications_", "interfaceGUJNotificationObserver.html#a45f112252d49645c07173809f59147af", null ],
    [ "registeredNotificationReceivers_", "interfaceGUJNotificationObserver.html#a207a7eace6b094a8e3d1235b216bea72", null ],
    [ "registeredNotificationSenders_", "interfaceGUJNotificationObserver.html#aa8269b01817260a80959618089a8c71e", null ]
];
var classGUJAdViewEvent =
[
    [ "GUJAdViewEventType", "classGUJAdViewEvent.html#a3bfc69bd2ef10178aa3da73438103148", [
      [ "GUJAdViewEventTypeUserInteraction", "classGUJAdViewEvent.html#a3bfc69bd2ef10178aa3da73438103148a765503d36154d62912b22540b9693c11", null ],
      [ "GUJAdViewEventTypeSystemMessage", "classGUJAdViewEvent.html#a3bfc69bd2ef10178aa3da73438103148ad18fbac4d8e57b47831f2af0ec1afc6f", null ],
      [ "GUJAdViewEventTypeTracking", "classGUJAdViewEvent.html#a3bfc69bd2ef10178aa3da73438103148ab1a6b2938d89810896d0b85bd39945d0", null ],
      [ "GUJAdViewEventTypeExternalFramework", "classGUJAdViewEvent.html#a3bfc69bd2ef10178aa3da73438103148a237c2a9345444ec6291b09695b43c3d4", null ]
    ] ],
    [ "eventForType:", "classGUJAdViewEvent.html#ab460270c43acc0743e1dcf812dd0c9e2", null ],
    [ "eventForType:attachment:", "classGUJAdViewEvent.html#af1d09057e3ec110ce0ba510ae413306f", null ],
    [ "eventForType:message:", "classGUJAdViewEvent.html#a8d7b9ae037dca2d1a38df87e960e394d", null ],
    [ "eventForType:message:attachment:", "classGUJAdViewEvent.html#a78187af73ef6c0554df561556b35f88b", null ],
    [ "_timestamp", "classGUJAdViewEvent.html#af412cdf73028ffce2b17beff49cf7762", null ],
    [ "attachment", "classGUJAdViewEvent.html#a5df9acdeae1f413666c1af3d2b12e5e0", null ],
    [ "message", "classGUJAdViewEvent.html#ab8a11ff3a5287690eee817a501d32ef7", null ],
    [ "timestamp", "classGUJAdViewEvent.html#a2ff7e739043bd0541ef9f74c8b531198", null ],
    [ "type", "classGUJAdViewEvent.html#a8ad3dcb490578e1c662c987414466805", null ]
];
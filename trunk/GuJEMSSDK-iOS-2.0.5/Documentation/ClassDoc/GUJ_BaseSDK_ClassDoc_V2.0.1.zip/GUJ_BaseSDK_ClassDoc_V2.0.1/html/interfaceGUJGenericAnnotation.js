var interfaceGUJGenericAnnotation =
[
    [ "coordinate", "interfaceGUJGenericAnnotation.html#a72bd65d38a4d29ff5b6db3ecb2d6650d", null ],
    [ "storeId", "interfaceGUJGenericAnnotation.html#a6742ea34b8582bff371b1053646e79a7", null ],
    [ "subtitle", "interfaceGUJGenericAnnotation.html#a4a60f6497ec904931de8eac429dd9f2d", null ],
    [ "title", "interfaceGUJGenericAnnotation.html#aa2be5c56e884196c1d12206f9f347bbd", null ]
];
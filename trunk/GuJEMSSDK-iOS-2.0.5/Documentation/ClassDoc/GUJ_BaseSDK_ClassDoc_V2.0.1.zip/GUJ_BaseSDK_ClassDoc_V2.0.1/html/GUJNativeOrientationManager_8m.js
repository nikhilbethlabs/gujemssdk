var GUJNativeOrientationManager_8m =
[
    [ "sharedInstance_", "GUJNativeOrientationManager_8m.html#a8466de78281e274c9e49e5fc856db9ec", null ]
];
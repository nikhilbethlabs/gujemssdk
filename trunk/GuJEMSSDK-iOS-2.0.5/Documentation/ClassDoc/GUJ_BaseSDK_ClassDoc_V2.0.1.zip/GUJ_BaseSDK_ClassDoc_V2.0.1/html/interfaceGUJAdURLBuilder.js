var interfaceGUJAdURLBuilder =
[
    [ "__adParameter:withValue:toURLString:", "interfaceGUJAdURLBuilder.html#a7e0ce1f17f608faf5a6d82ffb5f826b9", null ],
    [ "__bannerMarkupAsString", "interfaceGUJAdURLBuilder.html#abda68f33f61c57f815d41e7934c0ca91", null ],
    [ "__bannerMarkupForType:", "interfaceGUJAdURLBuilder.html#aaca2fc856b6933cf2d5381064b1d2cba", null ],
    [ "__bannerTypeAsNumber", "interfaceGUJAdURLBuilder.html#a3952bffa171544d86f46f1c4f5635e65", null ],
    [ "buildURL", "interfaceGUJAdURLBuilder.html#ad7412f216ec609a9d4461df0745ab679", null ],
    [ "buildURLString", "interfaceGUJAdURLBuilder.html#a8e68a48d7644fe35efeda9500e56773f", null ],
    [ "initWithAdConfiguration:", "interfaceGUJAdURLBuilder.html#a1f54287edfe9742b1b5270785f774ee0", null ],
    [ "setValue:forURLParameter:", "interfaceGUJAdURLBuilder.html#a16c6b4f2796823d93d1858912a623c85", null ],
    [ "valueForURLParameter:", "interfaceGUJAdURLBuilder.html#a38310b4b84cad0fc66f9177544720995", null ],
    [ "adConfiguration", "interfaceGUJAdURLBuilder.html#a6802f8eec470176e302dc9f438661dbe", null ],
    [ "bannerFormat", "interfaceGUJAdURLBuilder.html#a3c9ad68949eadef03a1fc550848d276e", null ],
    [ "bannerMarkup", "interfaceGUJAdURLBuilder.html#a26781e3003568c6728b568e78415b5f3", null ],
    [ "bannerType", "interfaceGUJAdURLBuilder.html#a5ab3d958b472f1f189aa73676ee0163d", null ],
    [ "urlParameter", "interfaceGUJAdURLBuilder.html#a6fefd618d4275d7bb494ccdfa2b95253", null ]
];
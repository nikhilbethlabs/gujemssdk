var files =
[
    [ "_GUJAdView.h", "__GUJAdView_8h.html", [
      [ "<GUJAdViewDelegate>", "protocolGUJAdViewDelegate-p.html", "protocolGUJAdViewDelegate-p" ],
      [ "_GUJAdView", "interface__GUJAdView.html", "interface__GUJAdView" ]
    ] ],
    [ "_GUJAdView.m", "__GUJAdView_8m.html", null ],
    [ "GUJAdConfiguration.h", "GUJAdConfiguration_8h.html", [
      [ "GUJAdConfiguration", "interfaceGUJAdConfiguration.html", "interfaceGUJAdConfiguration" ]
    ] ],
    [ "GUJAdConfiguration.m", "GUJAdConfiguration_8m.html", null ],
    [ "GUJAdData.h", "GUJAdData_8h.html", [
      [ "GUJAdData", "interfaceGUJAdData.html", "interfaceGUJAdData" ]
    ] ],
    [ "GUJAdData.m", "GUJAdData_8m.html", "GUJAdData_8m" ],
    [ "GUJAdURL.h", "GUJAdURL_8h.html", [
      [ "GUJAdURL", "interfaceGUJAdURL.html", "interfaceGUJAdURL" ]
    ] ],
    [ "GUJAdURL.m", "GUJAdURL_8m.html", null ],
    [ "GUJAdURLBuilder.h", "GUJAdURLBuilder_8h.html", [
      [ "GUJAdURLBuilder", "interfaceGUJAdURLBuilder.html", "interfaceGUJAdURLBuilder" ],
      [ "GUJAdURLBuilder(Private)", "categoryGUJAdURLBuilder_07Private_08.html", "categoryGUJAdURLBuilder_07Private_08" ]
    ] ],
    [ "GUJAdURLBuilder.m", "GUJAdURLBuilder_8m.html", "GUJAdURLBuilder_8m" ],
    [ "GUJAdViewController+PrivateImplementation.h", "GUJAdViewController_09PrivateImplementation_8h.html", [
      [ "GUJAdViewController(PrivateImplementation)", "categoryGUJAdViewController_07PrivateImplementation_08.html", "categoryGUJAdViewController_07PrivateImplementation_08" ]
    ] ],
    [ "GUJAdViewController.h", "GUJAdViewController_8h.html", [
      [ "GUJAdViewEvent", "classGUJAdViewEvent.html", "classGUJAdViewEvent" ],
      [ "GUJAdViewController", "interfaceGUJAdViewController.html", "interfaceGUJAdViewController" ]
    ] ],
    [ "GUJAdViewController.m", "GUJAdViewController_8m.html", [
      [ "GUJAdView", "interfaceGUJAdView.html", null ]
    ] ],
    [ "GUJAdViewControllerDelegate.h", "GUJAdViewControllerDelegate_8h.html", [
      [ "<GUJAdViewControllerDelegate>", "protocolGUJAdViewControllerDelegate-p.html", "protocolGUJAdViewControllerDelegate-p" ]
    ] ],
    [ "GUJAdViewEvent.h", "GUJAdViewEvent_8h.html", [
      [ "GUJAdViewEvent(Private)", "categoryGUJAdViewEvent_07Private_08.html", "categoryGUJAdViewEvent_07Private_08" ]
    ] ],
    [ "GUJAdViewEvent.m", "GUJAdViewEvent_8m.html", null ],
    [ "GUJAnimatedGif.h", "GUJAnimatedGif_8h.html", [
      [ "GUJAnimatedGifQueueObject", "interfaceGUJAnimatedGifQueueObject.html", "interfaceGUJAnimatedGifQueueObject" ],
      [ "GUJAnimatedGif", "interfaceGUJAnimatedGif.html", "interfaceGUJAnimatedGif" ]
    ] ],
    [ "GUJAnimatedGif.m", "GUJAnimatedGif_8m.html", "GUJAnimatedGif_8m" ],
    [ "GUJBannerXMLParser.h", "GUJBannerXMLParser_8h.html", "GUJBannerXMLParser_8h" ],
    [ "GUJBannerXMLParser.m", "GUJBannerXMLParser_8m.html", null ],
    [ "GUJBase64Util.h", "GUJBase64Util_8h.html", [
      [ "GUJBase64Util", "interfaceGUJBase64Util.html", "interfaceGUJBase64Util" ]
    ] ],
    [ "GUJBase64Util.m", "GUJBase64Util_8m.html", "GUJBase64Util_8m" ],
    [ "GUJBaseSDKVersion.h", "GUJBaseSDKVersion_8h.html", "GUJBaseSDKVersion_8h" ],
    [ "GUJConstants.h", "GUJConstants_8h.html", "GUJConstants_8h" ],
    [ "GUJDeviceCapabilities.h", "GUJDeviceCapabilities_8h.html", [
      [ "GUJDeviceCapabilities", "interfaceGUJDeviceCapabilities.html", "interfaceGUJDeviceCapabilities" ]
    ] ],
    [ "GUJDeviceCapabilities.m", "GUJDeviceCapabilities_8m.html", "GUJDeviceCapabilities_8m" ],
    [ "GUJLocalTypeDefinition.h", "GUJLocalTypeDefinition_8h.html", "GUJLocalTypeDefinition_8h" ],
    [ "GUJMacros.h", "GUJMacros_8h.html", "GUJMacros_8h" ],
    [ "GUJModalViewController.h", "GUJModalViewController_8h.html", "GUJModalViewController_8h" ],
    [ "GUJModalViewController.m", "GUJModalViewController_8m.html", null ],
    [ "GUJNativeAPIInterface.h", "GUJNativeAPIInterface_8h.html", [
      [ "GUJNativeAPIInterface", "interfaceGUJNativeAPIInterface.html", "interfaceGUJNativeAPIInterface" ],
      [ "GUJNativeAPIInterface(Private)", "categoryGUJNativeAPIInterface_07Private_08.html", "categoryGUJNativeAPIInterface_07Private_08" ]
    ] ],
    [ "GUJNativeAPIInterface.m", "GUJNativeAPIInterface_8m.html", null ],
    [ "GUJNativeAudioPlayer.h", "GUJNativeAudioPlayer_8h.html", [
      [ "GUJNativeAudioPlayer", "interfaceGUJNativeAudioPlayer.html", "interfaceGUJNativeAudioPlayer" ]
    ] ],
    [ "GUJNativeAudioPlayer.m", "GUJNativeAudioPlayer_8m.html", null ],
    [ "GUJNativeCalendar.h", "GUJNativeCalendar_8h.html", [
      [ "GUJNativeCalendar", "interfaceGUJNativeCalendar.html", "interfaceGUJNativeCalendar" ]
    ] ],
    [ "GUJNativeCalendar.m", "GUJNativeCalendar_8m.html", null ],
    [ "GUJNativeCamera.h", "GUJNativeCamera_8h.html", [
      [ "GUJNativeCamera", "interfaceGUJNativeCamera.html", "interfaceGUJNativeCamera" ]
    ] ],
    [ "GUJNativeCamera.m", "GUJNativeCamera_8m.html", null ],
    [ "GUJNativeEmailComposer.h", "GUJNativeEmailComposer_8h.html", [
      [ "GUJNativeEmailComposer", "interfaceGUJNativeEmailComposer.html", "interfaceGUJNativeEmailComposer" ]
    ] ],
    [ "GUJNativeEmailComposer.m", "GUJNativeEmailComposer_8m.html", null ],
    [ "GUJNativeKeyboardObserver.h", "GUJNativeKeyboardObserver_8h.html", [
      [ "GUJNativeKeyboardObserver", "interfaceGUJNativeKeyboardObserver.html", "interfaceGUJNativeKeyboardObserver" ]
    ] ],
    [ "GUJNativeKeyboardObserver.m", "GUJNativeKeyboardObserver_8m.html", "GUJNativeKeyboardObserver_8m" ],
    [ "GUJNativeLocationManager.h", "GUJNativeLocationManager_8h.html", [
      [ "GUJNativeLocationManager", "interfaceGUJNativeLocationManager.html", "interfaceGUJNativeLocationManager" ]
    ] ],
    [ "GUJNativeLocationManager.m", "GUJNativeLocationManager_8m.html", "GUJNativeLocationManager_8m" ],
    [ "GUJNativeMapView.h", "GUJNativeMapView_8h.html", [
      [ "GUJNativeMapView", "interfaceGUJNativeMapView.html", "interfaceGUJNativeMapView" ],
      [ "GUJGenericAnnotation", "interfaceGUJGenericAnnotation.html", "interfaceGUJGenericAnnotation" ]
    ] ],
    [ "GUJNativeMapView.m", "GUJNativeMapView_8m.html", null ],
    [ "GUJNativeMoviePlayer.h", "GUJNativeMoviePlayer_8h.html", [
      [ "GUJNativeMoviePlayer", "interfaceGUJNativeMoviePlayer.html", "interfaceGUJNativeMoviePlayer" ]
    ] ],
    [ "GUJNativeMoviePlayer.m", "GUJNativeMoviePlayer_8m.html", null ],
    [ "GUJNativeNetworkObserver.h", "GUJNativeNetworkObserver_8h.html", [
      [ "GUJNativeNetworkObserver", "interfaceGUJNativeNetworkObserver.html", "interfaceGUJNativeNetworkObserver" ]
    ] ],
    [ "GUJNativeNetworkObserver.m", "GUJNativeNetworkObserver_8m.html", "GUJNativeNetworkObserver_8m" ],
    [ "GUJNativeOrientationManager.h", "GUJNativeOrientationManager_8h.html", [
      [ "GUJNativeOrientationManager", "interfaceGUJNativeOrientationManager.html", "interfaceGUJNativeOrientationManager" ]
    ] ],
    [ "GUJNativeOrientationManager.m", "GUJNativeOrientationManager_8m.html", "GUJNativeOrientationManager_8m" ],
    [ "GUJNativePhoneCall.h", "GUJNativePhoneCall_8h.html", [
      [ "GUJNativePhoneCall", "interfaceGUJNativePhoneCall.html", "interfaceGUJNativePhoneCall" ]
    ] ],
    [ "GUJNativePhoneCall.m", "GUJNativePhoneCall_8m.html", null ],
    [ "GUJNativeShakeObserver.h", "GUJNativeShakeObserver_8h.html", [
      [ "GUJNativeShakeObserver", "interfaceGUJNativeShakeObserver.html", "interfaceGUJNativeShakeObserver" ]
    ] ],
    [ "GUJNativeShakeObserver.m", "GUJNativeShakeObserver_8m.html", "GUJNativeShakeObserver_8m" ],
    [ "GUJNativeSizeObserver.h", "GUJNativeSizeObserver_8h.html", [
      [ "GUJNativeSizeObserver", "interfaceGUJNativeSizeObserver.html", "interfaceGUJNativeSizeObserver" ]
    ] ],
    [ "GUJNativeSizeObserver.m", "GUJNativeSizeObserver_8m.html", "GUJNativeSizeObserver_8m" ],
    [ "GUJNativeSMSComposer.h", "GUJNativeSMSComposer_8h.html", [
      [ "GUJNativeSMSComposer", "interfaceGUJNativeSMSComposer.html", "interfaceGUJNativeSMSComposer" ]
    ] ],
    [ "GUJNativeSMSComposer.m", "GUJNativeSMSComposer_8m.html", null ],
    [ "GUJNativeTiltObserver.h", "GUJNativeTiltObserver_8h.html", [
      [ "GUJNativeTiltObserver", "interfaceGUJNativeTiltObserver.html", "interfaceGUJNativeTiltObserver" ]
    ] ],
    [ "GUJNativeTiltObserver.m", "GUJNativeTiltObserver_8m.html", "GUJNativeTiltObserver_8m" ],
    [ "GUJNotificationObserver.h", "GUJNotificationObserver_8h.html", [
      [ "GUJNotificationObserver", "interfaceGUJNotificationObserver.html", "interfaceGUJNotificationObserver" ]
    ] ],
    [ "GUJNotificationObserver.m", "GUJNotificationObserver_8m.html", null ],
    [ "GUJObserver.h", "GUJObserver_8h.html", [
      [ "GUJObserver", "interfaceGUJObserver.html", "interfaceGUJObserver" ]
    ] ],
    [ "GUJObserver.m", "GUJObserver_8m.html", null ],
    [ "GUJServerConnection.h", "GUJServerConnection_8h.html", "GUJServerConnection_8h" ],
    [ "GUJServerConnection.m", "GUJServerConnection_8m.html", null ],
    [ "GUJUtil.h", "GUJUtil_8h.html", "GUJUtil_8h" ],
    [ "GUJUtil.m", "GUJUtil_8m.html", null ]
];
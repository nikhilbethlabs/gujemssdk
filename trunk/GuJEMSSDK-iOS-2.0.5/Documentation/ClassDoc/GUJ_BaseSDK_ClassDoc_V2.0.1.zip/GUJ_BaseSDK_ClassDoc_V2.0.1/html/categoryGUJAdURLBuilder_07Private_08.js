var categoryGUJAdURLBuilder_07Private_08 =
[
    [ "__adParameter:withValue:toURLString:", "categoryGUJAdURLBuilder_07Private_08.html#a581688be4944587c60e85b6f0f287c2d", null ],
    [ "__bannerMarkupAsString", "categoryGUJAdURLBuilder_07Private_08.html#a84033f78e3db3a485a3425d14c818f04", null ],
    [ "__bannerTypeAsNumber", "categoryGUJAdURLBuilder_07Private_08.html#ac4ea49d427b1e9dd8950d237572cf059", null ]
];
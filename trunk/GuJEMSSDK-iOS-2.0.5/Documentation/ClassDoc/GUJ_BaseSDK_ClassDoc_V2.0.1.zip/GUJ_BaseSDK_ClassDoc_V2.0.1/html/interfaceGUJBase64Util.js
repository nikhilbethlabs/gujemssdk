var interfaceGUJBase64Util =
[
    [ "base64DataFromString:", "interfaceGUJBase64Util.html#ac16395cbe1bd267162da650f863105e0", null ],
    [ "base64StringFromData:length:", "interfaceGUJBase64Util.html#a53a21b761047629172cefa8b93b83a9f", null ]
];
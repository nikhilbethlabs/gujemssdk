var GUJNativeShakeObserver_8m =
[
    [ "sharedInstance_", "GUJNativeShakeObserver_8m.html#a648e98b9ce75dfa25982db31f28ed9a5", null ]
];
var interfaceGUJNativeAPIInterface =
[
    [ "__setRequiredDeviceCapability:", "interfaceGUJNativeAPIInterface.html#a859025ef59420891cd420a641e74e399", null ],
    [ "freeInstance", "interfaceGUJNativeAPIInterface.html#a73b3fa4b8a62d079da2faf9df18daa97", null ],
    [ "isAvailableForCurrentDevice", "interfaceGUJNativeAPIInterface.html#a9f08a345d2463ad5c10ccd40c08e41ce", null ],
    [ "isObserver", "interfaceGUJNativeAPIInterface.html#ac030f48dae269a050c816150a53bf33f", null ],
    [ "willPostNotification", "interfaceGUJNativeAPIInterface.html#acfa9e54dbddfd400bd227eaf7add598a", null ],
    [ "error", "interfaceGUJNativeAPIInterface.html#ab959a04ffe67b5b827516c2826e47586", null ],
    [ "rquiredDeviceCapability_", "interfaceGUJNativeAPIInterface.html#a96ce87ac4deea30b1223e9df4c3f344c", null ]
];
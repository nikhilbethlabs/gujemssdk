var protocolGUJAdViewControllerDelegate_p =
[
    [ "adViewController:canDisplayAdView:", "protocolGUJAdViewControllerDelegate-p.html#a91d63784b30ef092194141a23b0ba50f", null ],
    [ "adViewController:didConfigurationFailure:", "protocolGUJAdViewControllerDelegate-p.html#a7e4880caaeab72d41e9faa0e9457ed8c", null ],
    [ "bannerView:didFailLoadingAdWithError:", "protocolGUJAdViewControllerDelegate-p.html#aa9d7a9dceee290c17dcd771c5d811a9a", null ],
    [ "bannerView:receivedEvent:", "protocolGUJAdViewControllerDelegate-p.html#a474e5008ff6cd05131b1496c6aa7a16a", null ],
    [ "bannerViewDidHide:", "protocolGUJAdViewControllerDelegate-p.html#a1fc906e2ce0ab8a50941416711f01f79", null ],
    [ "bannerViewDidLoad:", "protocolGUJAdViewControllerDelegate-p.html#a2387c4278ecd1406f1ae8764055c392c", null ],
    [ "bannerViewDidLoadAdData:", "protocolGUJAdViewControllerDelegate-p.html#a63bd619f17661da2b75bbfb61dfebcdb", null ],
    [ "bannerViewDidShow:", "protocolGUJAdViewControllerDelegate-p.html#a41da3c73cc734e9f9a21cbcb00c5cd21", null ],
    [ "bannerViewInitialized:", "protocolGUJAdViewControllerDelegate-p.html#ac6cb82174d4659a3e558cce472c71f98", null ],
    [ "bannerViewWillLoadAdData:", "protocolGUJAdViewControllerDelegate-p.html#a46e10a9f341cf4ad568d1ca91fafb12a", null ],
    [ "interstitialView:didFailLoadingAdWithError:", "protocolGUJAdViewControllerDelegate-p.html#a6dc1c435c36dcfd612d7b6829a124437", null ],
    [ "interstitialViewDidAppear", "protocolGUJAdViewControllerDelegate-p.html#a22a907a67b5ef6861b6a629e72a7b675", null ],
    [ "interstitialViewDidDisappear", "protocolGUJAdViewControllerDelegate-p.html#a9c83aaffcf556ed2edc475b356db9299", null ],
    [ "interstitialViewDidFailLoadingWithError:", "protocolGUJAdViewControllerDelegate-p.html#ab9def676dda2b842cbab9eaae6bd2e24", null ],
    [ "interstitialViewDidLoadAdData:", "protocolGUJAdViewControllerDelegate-p.html#afaf92dc39b083ba43b054db626d71552", null ],
    [ "interstitialViewInitialized:", "protocolGUJAdViewControllerDelegate-p.html#a3279253210fc46b0fd9c1fef6008ce39", null ],
    [ "interstitialViewReceivedEvent:", "protocolGUJAdViewControllerDelegate-p.html#a4967dd09d301928d9688c044120038c4", null ],
    [ "interstitialViewWillAppear", "protocolGUJAdViewControllerDelegate-p.html#a901e5321515b8407616fdaf0494f8b79", null ],
    [ "interstitialViewWillDisappear", "protocolGUJAdViewControllerDelegate-p.html#a66d811fc28eee7e74bb5d262f8039dbc", null ],
    [ "interstitialViewWillLoadAdData:", "protocolGUJAdViewControllerDelegate-p.html#a5bc61dfaa130d10816d63d77c22c133b", null ]
];
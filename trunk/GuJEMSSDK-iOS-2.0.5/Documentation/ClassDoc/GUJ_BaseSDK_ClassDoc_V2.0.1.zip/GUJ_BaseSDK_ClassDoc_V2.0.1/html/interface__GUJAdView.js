var interface__GUJAdView =
[
    [ "__adDataFailedLoading", "interface__GUJAdView.html#ae2e936d028feaddf5ae45872cda81f4f", null ],
    [ "__adDataLoaded:", "interface__GUJAdView.html#a76f7cc6a3a060c512ee5ea8245f2b33b", null ],
    [ "__free", "interface__GUJAdView.html#ac2a54513cc5a8128f267a16740f456a3", null ],
    [ "__loadAd", "interface__GUJAdView.html#a14888ebaff2c518c94cd7a1679ff2b6a", null ],
    [ "__loadAd:", "interface__GUJAdView.html#ae0b0f886092b1fd0c2dbee9bc5c2c3ab", null ],
    [ "__reloadAd", "interface__GUJAdView.html#ad84a0389d0ecee143ec1ee5f590c0f22", null ],
    [ "__unload", "interface__GUJAdView.html#a3213982806793648ba328673ea5bbff8", null ],
    [ "adSpaceId", "interface__GUJAdView.html#a12d22295e8b593762f8e8641e52d995f", null ],
    [ "initWithFrame:", "interface__GUJAdView.html#aa55a4860ebfb03d56c38327d0f802f0a", null ],
    [ "initWithFrame:delegate:", "interface__GUJAdView.html#a6401b785f30c948b9c37efcc6ef3f2f6", null ],
    [ "adConfiguration", "interface__GUJAdView.html#a25398d107a84d0215e610253b32c2282", null ],
    [ "adData", "interface__GUJAdView.html#a5e7398fa6bb86c95a601f4f7758d928b", null ],
    [ "adViewCompletionHandler", "interface__GUJAdView.html#a12433cd4cdb02131cdaae65450513fd9", null ],
    [ "adViewIsLoadingAdData", "interface__GUJAdView.html#aea740d4773f77310b046b5b1990e8db9", null ],
    [ "delegate", "interface__GUJAdView.html#acadfeb050946473fd0cb138d7c995416", null ],
    [ "initialAdViewOrigin", "interface__GUJAdView.html#a9f5c868aad5df2dbd9c3c63b770e2f17", null ],
    [ "lastAdLoadedTime", "interface__GUJAdView.html#a2e65ee42d77d516a2ba05f67e0ed45cb", null ]
];
var GUJBannerXMLParser_8h =
[
    [ "GUJBannerXMLParser", "interfaceGUJBannerXMLParser.html", "interfaceGUJBannerXMLParser" ],
    [ "kGUJBannerXMLAttributeForAdId", "GUJBannerXMLParser_8h.html#a12198e3a16abaa5e2a44ad8c0fed4cd6", null ],
    [ "kGUJBannerXMLAttributeForAlign", "GUJBannerXMLParser_8h.html#adca90028332b1439cec246ed504d1cdd", null ],
    [ "kGUJBannerXMLAttributeForCampaignId", "GUJBannerXMLParser_8h.html#a0e4e930190294e2e319482bb56989b80", null ],
    [ "kGUJBannerXMLAttributeForHref", "GUJBannerXMLParser_8h.html#afe56f0fdbd12b03a1574a275739f3095", null ],
    [ "kGUJBannerXMLAttributeForMimeType", "GUJBannerXMLParser_8h.html#a2707dbbbf4465c9343a2dcb8a12e1203", null ],
    [ "kGUJBannerXMLAttributeForScale", "GUJBannerXMLParser_8h.html#ac1eb5ef2a30ffcc69d6b46bf88b91cea", null ],
    [ "kGUJBannerXMLAttributeForSrc", "GUJBannerXMLParser_8h.html#af159d1af76d2adf43bd85df3a1c6b4d8", null ],
    [ "kGUJBannerXMLTagForAd", "GUJBannerXMLParser_8h.html#aa86b923d98ae2a5a94bed7989d64fc35", null ],
    [ "kGUJBannerXMLTagForBanner", "GUJBannerXMLParser_8h.html#ae02656b671c1b571c6e813bccdb641b3", null ],
    [ "kGUJBannerXMLTagForBannerXML", "GUJBannerXMLParser_8h.html#a5b9bec4064e87f27299957269eb8c46a", null ],
    [ "kGUJBannerXMLTagForImage", "GUJBannerXMLParser_8h.html#a45610fb8349fa293129c506a4956dd4e", null ],
    [ "kGUJBannerXMLTagForImageLink", "GUJBannerXMLParser_8h.html#ac71ca2e04111bbfb6a50f54cef3177a8", null ]
];
var interfaceGUJNativeAudioPlayer =
[
    [ "__initializePlayerWithURL:", "interfaceGUJNativeAudioPlayer.html#ad3551d0bda29ffac600e3508eafd06f8", null ],
    [ "__postChangeNotificationForState:", "interfaceGUJNativeAudioPlayer.html#a75ed856c0cc5a445b8da64bf5e893ce2", null ],
    [ "audioPlayBackDidFinish:", "interfaceGUJNativeAudioPlayer.html#ab8b8a020620ee84026375fe04a9a8353", null ],
    [ "audioPlayerLoadStateChanged:", "interfaceGUJNativeAudioPlayer.html#a7ef500adb72e766145a0f66db2191367", null ],
    [ "canPlayAudio", "interfaceGUJNativeAudioPlayer.html#ab55c3ad320e8c931f3e78aea747b28f3", null ],
    [ "freeInstance", "interfaceGUJNativeAudioPlayer.html#a6ccd470ca2ab6e03f165d801b6a5ce8a", null ],
    [ "init", "interfaceGUJNativeAudioPlayer.html#aceb6bf4b1f5917a16350fe793a1e2f88", null ],
    [ "moviePlaybackStateDidChange:", "interfaceGUJNativeAudioPlayer.html#afe2ccb724ba5bb4cbc040938b6b0357e", null ],
    [ "pauseAudio", "interfaceGUJNativeAudioPlayer.html#ade4eb2a281e90fce8cb4e15ea8104413", null ],
    [ "playAudio:", "interfaceGUJNativeAudioPlayer.html#a52ff0f4b5a57230b62fab894dbaf4c34", null ],
    [ "stopAudio", "interfaceGUJNativeAudioPlayer.html#a723bd8a95899dac2087ba20f67262799", null ],
    [ "willPostNotification", "interfaceGUJNativeAudioPlayer.html#a6ee1c25a0db51676afb371b7909013e4", null ],
    [ "audioPlayer", "interfaceGUJNativeAudioPlayer.html#a644e73af82ae778a1ccd0cd4f772b029", null ],
    [ "autoPlay", "interfaceGUJNativeAudioPlayer.html#aa48ece047a0312bcdfa89a1b5798457b", null ],
    [ "closeOnStop", "interfaceGUJNativeAudioPlayer.html#a92d2ec50f9323c9497189c67f5e25617", null ],
    [ "hideControls", "interfaceGUJNativeAudioPlayer.html#acc681ee26bc4bc83db18029c33e67dd2", null ],
    [ "loopPlayback", "interfaceGUJNativeAudioPlayer.html#a6d57f0450f94bd5e3d88ceb5f5214159", null ],
    [ "state", "interfaceGUJNativeAudioPlayer.html#ac08cd6f5b53c05b06f0426d98e05e1d6", null ]
];
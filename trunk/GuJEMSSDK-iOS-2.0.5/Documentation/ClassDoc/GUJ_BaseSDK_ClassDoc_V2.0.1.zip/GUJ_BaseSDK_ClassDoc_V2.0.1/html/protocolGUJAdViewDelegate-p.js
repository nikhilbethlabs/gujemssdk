var protocolGUJAdViewDelegate_p =
[
    [ "view:didFailToLoadAdWithUrl:andError:", "protocolGUJAdViewDelegate-p.html#aaf9ecea1914cb974cfc829eb62ae0209", null ],
    [ "view:didLoadAd:", "protocolGUJAdViewDelegate-p.html#a77643400165ef3db82293c5ffe5b5096", null ],
    [ "viewWillLoadAd:", "protocolGUJAdViewDelegate-p.html#a2a92b4900a66f2c1499c836301a850ae", null ]
];
var interfaceGUJNativeNetworkObserver =
[
    [ "__networkChangedListenerEvent", "interfaceGUJNativeNetworkObserver.html#ac49993e84ac70ea1a954982c0fdc2641", null ],
    [ "__startEventListener", "interfaceGUJNativeNetworkObserver.html#a57b1c41e1f8609e93af845dfd53149b3", null ],
    [ "__stopEventListener", "interfaceGUJNativeNetworkObserver.html#a6e1c203cac8f315249153553281d1285", null ],
    [ "freeInstance", "interfaceGUJNativeNetworkObserver.html#a144abbe41ac826cf333af99e087e620e", null ],
    [ "isCellular", "interfaceGUJNativeNetworkObserver.html#a9994e215af0c80e332437166a185018c", null ],
    [ "isObserver", "interfaceGUJNativeNetworkObserver.html#a2947737cafb90816a666bf8810490993", null ],
    [ "isOflline", "interfaceGUJNativeNetworkObserver.html#af8572f08f19259893c67d2f94c6dd593", null ],
    [ "isWiFi", "interfaceGUJNativeNetworkObserver.html#ab6fad5487e202ab439eb6d965b062515", null ],
    [ "networkInterfaceAddressStringRepresentation", "interfaceGUJNativeNetworkObserver.html#a72198d2cbdd64b1efde5bec32a12c46d", null ],
    [ "networkInterfaceName", "interfaceGUJNativeNetworkObserver.html#a4d11119fa3502ffd19d5f6cd76c87ab0", null ],
    [ "sharedInstance", "interfaceGUJNativeNetworkObserver.html#a88986c61d2b1c5f574c9b617b099f7d4", null ],
    [ "startObserver", "interfaceGUJNativeNetworkObserver.html#a3d621a398457c78e7e717a3ea5f7d6e4", null ],
    [ "stopObserver", "interfaceGUJNativeNetworkObserver.html#aa1253a382b226daf90b6509609ea1c4c", null ],
    [ "willPostNotification", "interfaceGUJNativeNetworkObserver.html#a37861fa823095561936626ad03c0109f", null ],
    [ "currentNetworkInterface", "interfaceGUJNativeNetworkObserver.html#a8e982a440e05348755ae4830633015a6", null ],
    [ "currentNetworkInterfaceAddress", "interfaceGUJNativeNetworkObserver.html#a7f6e3d2c1dd87eeb7602ecc2f03fa978", null ],
    [ "runLoop", "interfaceGUJNativeNetworkObserver.html#a06f0a157b4b0861989f2b717b47ee489", null ],
    [ "timer", "interfaceGUJNativeNetworkObserver.html#a52a2149973267decca24e4b3231d7852", null ]
];
var classGUJServerConnection =
[
    [ "__preprocessResponseHeader", "classGUJServerConnection.html#a37df4a760343bcb4766925e8c7677828", null ],
    [ "adServerRequestWithConfiguration:completion:", "classGUJServerConnection.html#a69ad83b63ce54755c53395e9c1d1b626", null ],
    [ "initWithAdConfiguration:", "classGUJServerConnection.html#a583d80a00c2e9bb0d763a9723a177358", null ],
    [ "sendAdServerRequest:", "classGUJServerConnection.html#a7f9f8e708571eb68a6427b4a7d0dfbf0", null ]
];
var categoryGUJAdViewEvent_07Private_08 =
[
    [ "eventForType:", "categoryGUJAdViewEvent_07Private_08.html#ae8e1d0025c7e583b026bd44c27badb5e", null ],
    [ "eventForType:attachment:", "categoryGUJAdViewEvent_07Private_08.html#a363191a22d78a4b44cd84e8131dece64", null ],
    [ "eventForType:message:", "categoryGUJAdViewEvent_07Private_08.html#a04ffeedf2e5dd2cfde76ff0095ce7e08", null ],
    [ "eventForType:message:attachment:", "categoryGUJAdViewEvent_07Private_08.html#a4ccbc255969d95e301f127582af2a2ce", null ]
];
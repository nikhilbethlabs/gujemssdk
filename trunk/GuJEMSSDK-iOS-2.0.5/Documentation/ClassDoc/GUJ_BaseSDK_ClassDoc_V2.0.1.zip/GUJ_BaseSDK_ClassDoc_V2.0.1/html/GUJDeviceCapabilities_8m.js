var GUJDeviceCapabilities_8m =
[
    [ "kGUJDeviceCapabilityNativeFrameworkBridgeClass", "GUJDeviceCapabilities_8m.html#a9a527bf2517568d7596121ea2358f17d", null ],
    [ "kGUJDeviceCapabilitySystemDependencyClass", "GUJDeviceCapabilities_8m.html#a2c31b6cebbd951e6088b689e7a1df9bc", null ],
    [ "sharedInstance_", "GUJDeviceCapabilities_8m.html#ac8ad1f797e5ba41f5641c30bb56ead14", null ]
];
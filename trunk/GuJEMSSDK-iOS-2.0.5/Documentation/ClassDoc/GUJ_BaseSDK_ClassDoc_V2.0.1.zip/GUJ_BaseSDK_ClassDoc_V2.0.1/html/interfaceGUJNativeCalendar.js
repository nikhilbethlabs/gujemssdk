var interfaceGUJNativeCalendar =
[
    [ "__addEvent:end:title:description:", "interfaceGUJNativeCalendar.html#ab244e0240a2cd4f31d4cd47b36e5e909", null ],
    [ "addEvent:end:title:description:", "interfaceGUJNativeCalendar.html#aa631e3d98c404cf7ce307954d15ce38f", null ],
    [ "canAddEvent", "interfaceGUJNativeCalendar.html#a9da8bdca2079aa75421eacb281954124", null ],
    [ "freeInstance", "interfaceGUJNativeCalendar.html#a3514bcd759f40c818cd93236c65710fc", null ],
    [ "init", "interfaceGUJNativeCalendar.html#ac0e95f623bb470f534bc3986d97466de", null ],
    [ "isAvailableForCurrentDevice", "interfaceGUJNativeCalendar.html#ac10ae21ab5fb1fdf63376245c4243dfa", null ]
];
var interfaceGUJNativeSMSComposer =
[
    [ "canComposeMessage", "interfaceGUJNativeSMSComposer.html#a1af9a1c6e13d1a715b1fa1faf41b2089", null ],
    [ "composeMessagelTo:title:body:", "interfaceGUJNativeSMSComposer.html#afb84c1d9362b4541c74ab5ee2d23f8aa", null ],
    [ "freeInstance", "interfaceGUJNativeSMSComposer.html#a4e57ce679e5fc59cbfd30b5556ee29ea", null ],
    [ "init", "interfaceGUJNativeSMSComposer.html#a2d602916d131ea8f4a2f921fc185d258", null ],
    [ "messageComposeViewController:didFinishWithResult:", "interfaceGUJNativeSMSComposer.html#adc8c0a1b476f8126586d1aaa8e2f7236", null ],
    [ "messageComposerVC", "interfaceGUJNativeSMSComposer.html#a6b69fe2056d1f5c53c753a17063065d8", null ]
];
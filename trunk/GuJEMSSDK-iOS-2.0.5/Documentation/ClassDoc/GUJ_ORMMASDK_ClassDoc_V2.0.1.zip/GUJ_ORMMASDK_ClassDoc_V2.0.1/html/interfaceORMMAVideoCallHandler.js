var interfaceORMMAVideoCallHandler =
[
    [ "__floatForPrameter:", "interfaceORMMAVideoCallHandler.html#a36c6006830cd164cc87d2a805d31b4c0", null ],
    [ "__hasProperty:", "interfaceORMMAVideoCallHandler.html#af83c29164bd54db36600fe63977b7868", null ],
    [ "__hasProperty:withValue:", "interfaceORMMAVideoCallHandler.html#a84d906a751206e241d7ccdc33c91d70a", null ],
    [ "performHandler:", "interfaceORMMAVideoCallHandler.html#aeff4d8024191028a9d18d5673211d8f0", null ]
];
var interfaceORMMAOpenCallHandler =
[
    [ "__hasProperty:", "interfaceORMMAOpenCallHandler.html#a9dbec90aa73a162e8732c3c0bcac4c1a", null ],
    [ "__stringValueForProperty:", "interfaceORMMAOpenCallHandler.html#a372fc5454bbd2448531db87ea59b833f", null ],
    [ "performHandler:", "interfaceORMMAOpenCallHandler.html#ac757f3b313b86e79eb016ded573214a5", null ]
];
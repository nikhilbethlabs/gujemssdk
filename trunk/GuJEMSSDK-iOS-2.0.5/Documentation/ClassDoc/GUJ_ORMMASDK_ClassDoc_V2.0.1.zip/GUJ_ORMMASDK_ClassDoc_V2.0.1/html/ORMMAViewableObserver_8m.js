var ORMMAViewableObserver_8m =
[
    [ "sharedInstance_", "ORMMAViewableObserver_8m.html#a72b0523334c28a73464d411f882136df", null ]
];
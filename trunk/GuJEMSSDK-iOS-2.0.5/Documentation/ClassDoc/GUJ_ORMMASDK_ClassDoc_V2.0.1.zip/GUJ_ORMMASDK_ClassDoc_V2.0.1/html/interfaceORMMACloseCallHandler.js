var interfaceORMMACloseCallHandler =
[
    [ "performHandler:", "interfaceORMMACloseCallHandler.html#a431440aac478e368e1c569e7f6a688a1", null ]
];
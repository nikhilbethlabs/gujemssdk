var categoryORMMAJavaScriptBridge_07PrivateORMMACallHandling_08 =
[
    [ "__distributeError:", "categoryORMMAJavaScriptBridge_07PrivateORMMACallHandling_08.html#a26048389ef1403b9b4087fe7e7cdfc36", null ],
    [ "__handleCall:", "categoryORMMAJavaScriptBridge_07PrivateORMMACallHandling_08.html#ab781bf6da437f764217fab5ab8da18bb", null ],
    [ "__handleServiceCall:", "categoryORMMAJavaScriptBridge_07PrivateORMMACallHandling_08.html#ab4adf3e6b7e05b89f48563d32950d183", null ],
    [ "observeValueForKeyPath:ofObject:change:context:", "categoryORMMAJavaScriptBridge_07PrivateORMMACallHandling_08.html#aa8f6227e9678f8a4decaa994e2885226", null ]
];
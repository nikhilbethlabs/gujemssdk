var interfaceORMMACalendarCallHandler =
[
    [ "__hasProperty:", "interfaceORMMACalendarCallHandler.html#a829191bd81a97598b3347a5dfe8cfd50", null ],
    [ "__stringValueForProperty:", "interfaceORMMACalendarCallHandler.html#a4698c1f9b6262fd481b1c87b68d80b46", null ],
    [ "performHandler:", "interfaceORMMACalendarCallHandler.html#af94ddd276e10a6617a13623b412c350f", null ]
];
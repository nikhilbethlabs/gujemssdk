var interfaceORMMAHideCallHandler =
[
    [ "performHandler:", "interfaceORMMAHideCallHandler.html#a600a620111481906b6d3fadc70fff1a3", null ]
];
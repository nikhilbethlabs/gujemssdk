var ORMMAStateObserver_8m =
[
    [ "sharedInstance_", "ORMMAStateObserver_8m.html#a26401eb5b7e3b2ffc1885034dcce45ae", null ]
];
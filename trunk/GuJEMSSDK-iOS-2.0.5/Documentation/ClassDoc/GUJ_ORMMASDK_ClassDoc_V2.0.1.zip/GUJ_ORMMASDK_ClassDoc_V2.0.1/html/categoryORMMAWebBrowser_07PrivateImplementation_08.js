var categoryORMMAWebBrowser_07PrivateImplementation_08 =
[
    [ "__createControllButton:target:action:", "categoryORMMAWebBrowser_07PrivateImplementation_08.html#a75f199be807e37fd292bee6476a90c12", null ],
    [ "__createFlexibleSpace", "categoryORMMAWebBrowser_07PrivateImplementation_08.html#ae17f237b8cb8235c24132de9dd71c235", null ],
    [ "__createUI:", "categoryORMMAWebBrowser_07PrivateImplementation_08.html#acef0fc5f7a655ba8a021691e1c2bcb82", null ],
    [ "close:", "categoryORMMAWebBrowser_07PrivateImplementation_08.html#a1e34c22ecbd5dc2986256cef8de785fb", null ],
    [ "navigateBack:", "categoryORMMAWebBrowser_07PrivateImplementation_08.html#a2c9b58468abfceb9c3f54900d45e5037", null ],
    [ "navigateForward:", "categoryORMMAWebBrowser_07PrivateImplementation_08.html#af88525932fd32144e07d794be98bc5e0", null ],
    [ "openExternal:", "categoryORMMAWebBrowser_07PrivateImplementation_08.html#abfbab93681d96ef68d8c7c4019759de1", null ],
    [ "refresh:", "categoryORMMAWebBrowser_07PrivateImplementation_08.html#a85c76bfa969f4bc8fc3afa7c36679991", null ]
];
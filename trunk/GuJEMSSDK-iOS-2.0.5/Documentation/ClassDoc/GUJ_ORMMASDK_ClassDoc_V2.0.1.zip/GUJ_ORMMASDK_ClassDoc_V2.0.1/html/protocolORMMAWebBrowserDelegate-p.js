var protocolORMMAWebBrowserDelegate_p =
[
    [ "webBrowserFailedStartLoadWithRequest:", "protocolORMMAWebBrowserDelegate-p.html#a306d9c75be2a238f23b6ac7bc534f4cf", null ],
    [ "webBrowserWillHide", "protocolORMMAWebBrowserDelegate-p.html#a442ba22b1228e941c48d372b17d0cb71", null ],
    [ "webBrowserWillShow", "protocolORMMAWebBrowserDelegate-p.html#abe9f1e38ccf6a4662be5b7c55637dafe", null ]
];
var categoryORMMACall_07PrivateImplementation_08 =
[
    [ "__isORMMACall:", "categoryORMMACall_07PrivateImplementation_08.html#ac0fb1fb4db8223c0aa6e3a35fa273cbc", null ],
    [ "__isORMMAServiceCall:", "categoryORMMACall_07PrivateImplementation_08.html#a69eee34b1b4a9c46a7a568b7961f2511", null ],
    [ "__isValidCallString:", "categoryORMMACall_07PrivateImplementation_08.html#a09203adb20e3d728b778482c615c4cb5", null ],
    [ "__parseCallString:", "categoryORMMACall_07PrivateImplementation_08.html#aba08307fc085d8fc6aafddbba0e096fa", null ]
];
var interfaceORMMASMSCallHandler =
[
    [ "__hasProperty:", "interfaceORMMASMSCallHandler.html#ab37547ba6f795111c4418d73d2382de4", null ],
    [ "__hasProperty:withValue:", "interfaceORMMASMSCallHandler.html#ac0d8f0d971441c8182fa021b037c028c", null ],
    [ "__stringValueForProperty:", "interfaceORMMASMSCallHandler.html#aeb069a513472cb0c29b357933d25702e", null ],
    [ "performHandler:", "interfaceORMMASMSCallHandler.html#a4ddc2fb155e1eab5c69a05ba2868494b", null ]
];
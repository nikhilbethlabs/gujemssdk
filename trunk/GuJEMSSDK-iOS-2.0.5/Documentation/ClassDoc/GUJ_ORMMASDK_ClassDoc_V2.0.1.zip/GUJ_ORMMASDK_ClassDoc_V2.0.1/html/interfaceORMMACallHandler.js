var interfaceORMMACallHandler =
[
    [ "handle:forAdView:completion:", "interfaceORMMACallHandler.html#a4cf484f283d7af74160b257884ab2685", null ],
    [ "handlerForCall:", "interfaceORMMACallHandler.html#a2610db6af660d7723007f24d445c1503", null ],
    [ "performHandler:", "interfaceORMMACallHandler.html#ae944ee01c3385be35c0cb85372d52588", null ],
    [ "adView", "interfaceORMMACallHandler.html#a25ea3d606da73d679788db3ea5ea6fbc", null ],
    [ "call", "interfaceORMMACallHandler.html#a4db0fcf61cf21e5b6e7e472c33c69654", null ],
    [ "error", "interfaceORMMACallHandler.html#ad9aeb9f4edb0354c723d1343755db691", null ]
];
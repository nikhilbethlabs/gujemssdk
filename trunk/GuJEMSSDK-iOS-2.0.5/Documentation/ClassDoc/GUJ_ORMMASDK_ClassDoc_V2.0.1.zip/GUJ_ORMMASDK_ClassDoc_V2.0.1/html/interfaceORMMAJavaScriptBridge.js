var interfaceORMMAJavaScriptBridge =
[
    [ "__distributeError:", "interfaceORMMAJavaScriptBridge.html#a26048389ef1403b9b4087fe7e7cdfc36", null ],
    [ "__handleCall:", "interfaceORMMAJavaScriptBridge.html#ab781bf6da437f764217fab5ab8da18bb", null ],
    [ "__handleServiceCall:", "interfaceORMMAJavaScriptBridge.html#ab4adf3e6b7e05b89f48563d32950d183", null ],
    [ "__nativeNotification:", "interfaceORMMAJavaScriptBridge.html#a5fd7bd3e660ae6c5b09b91ed422f7c22", null ],
    [ "__performInitialORMMASequence", "interfaceORMMAJavaScriptBridge.html#a9d376286411fa1db946b28689f7e27ca", null ],
    [ "attachToAdView:", "interfaceORMMAJavaScriptBridge.html#a32e11268c34dff72c68731ebb8ee4dbf", null ],
    [ "executeCommand:", "interfaceORMMAJavaScriptBridge.html#a15bdb1f0e09b799271d61134ea1acd07", null ],
    [ "handleRequest:", "interfaceORMMAJavaScriptBridge.html#ab9625d3ac3fcb1c1d48f5fc30539c232", null ],
    [ "initializeORMMAAndDisplayAdView", "interfaceORMMAJavaScriptBridge.html#a191f1ca8b234e3eae67e263c82587c90", null ],
    [ "initWithAdView:", "interfaceORMMAJavaScriptBridge.html#aa79d4ed5b28148eefb8b61c2b7432130", null ],
    [ "isAttachedToAdView", "interfaceORMMAJavaScriptBridge.html#a9cab0ade14f946eea25fbb36d829f0a1", null ],
    [ "isAttachedToAdView:", "interfaceORMMAJavaScriptBridge.html#a4ca47ccb5b2da2e8bd6f0624edf545b3", null ],
    [ "observeValueForKeyPath:ofObject:change:context:", "interfaceORMMAJavaScriptBridge.html#aa8f6227e9678f8a4decaa994e2885226", null ],
    [ "unload", "interfaceORMMAJavaScriptBridge.html#a6d5967aeb81241d33d22ca41bf795238", null ],
    [ "internalWebBrowser", "interfaceORMMAJavaScriptBridge.html#ae4da84c28c3c9e00f08818d2f648509c", null ],
    [ "ormmaInit", "interfaceORMMAJavaScriptBridge.html#a0dcb831062e3abdab85574b50feb195c", null ],
    [ "ormmaSetup", "interfaceORMMAJavaScriptBridge.html#a11376938d33582b6ad5170c538818154", null ],
    [ "ormmaSupportString", "interfaceORMMAJavaScriptBridge.html#a88ee1781aa51f30b802b72e71adede39", null ],
    [ "ormmaView", "interfaceORMMAJavaScriptBridge.html#a7ba531636dd045b7d6d27fc15842f95f", null ],
    [ "shouldReportErrors", "interfaceORMMAJavaScriptBridge.html#a215f34182f9723305175e42f59234db7", null ]
];
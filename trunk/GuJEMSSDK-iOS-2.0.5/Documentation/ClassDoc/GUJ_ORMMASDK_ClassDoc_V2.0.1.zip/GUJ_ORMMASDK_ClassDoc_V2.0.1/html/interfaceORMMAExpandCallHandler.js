var interfaceORMMAExpandCallHandler =
[
    [ "__floatForPrameter:", "interfaceORMMAExpandCallHandler.html#aabba51623fac9ba7afef1d899eaf1edf", null ],
    [ "performHandler:", "interfaceORMMAExpandCallHandler.html#a6b5ab976897c80996f81b7094ee072e7", null ]
];
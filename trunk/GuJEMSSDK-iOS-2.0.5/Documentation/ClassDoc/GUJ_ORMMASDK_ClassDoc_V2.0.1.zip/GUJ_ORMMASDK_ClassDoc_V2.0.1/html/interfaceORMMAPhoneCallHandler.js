var interfaceORMMAPhoneCallHandler =
[
    [ "__hasProperty:", "interfaceORMMAPhoneCallHandler.html#abecd1bd9e077f9b8550f2409b94ceb94", null ],
    [ "__stringValueForProperty:", "interfaceORMMAPhoneCallHandler.html#a8a907535617ade059f3c1cd4614f7f00", null ],
    [ "performHandler:", "interfaceORMMAPhoneCallHandler.html#a9993cf96bf003d11218c2f81135f97cd", null ]
];
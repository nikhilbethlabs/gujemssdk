var hierarchy =
[
    [ "_GUJAdView", "class__GUJAdView.html", [
      [ "ORMMAView", "interfaceORMMAView.html", null ]
    ] ],
    [ "GUJAdViewController", "classGUJAdViewController.html", [
      [ "ORMMAViewController", "interfaceORMMAViewController.html", null ]
    ] ],
    [ "<GUJAdViewControllerDelegate>", "classGUJAdViewControllerDelegate-p.html", [
      [ "ORMMAView", "interfaceORMMAView.html", null ],
      [ "ORMMAViewController", "interfaceORMMAViewController.html", null ],
      [ "ORMMAViewController(PrivateImplementation)", "categoryORMMAViewController_07PrivateImplementation_08.html", null ]
    ] ],
    [ "<GUJAdViewDelegate>", "classGUJAdViewDelegate-p.html", [
      [ "ORMMAView", "interfaceORMMAView.html", null ],
      [ "ORMMAViewController(PrivateImplementation)", "categoryORMMAViewController_07PrivateImplementation_08.html", null ]
    ] ],
    [ "GUJModalViewController", "classGUJModalViewController.html", [
      [ "ORMMAInterstitialViewController", "interfaceORMMAInterstitialViewController.html", null ]
    ] ],
    [ "<GUJModalViewControllerDelegate>", "classGUJModalViewControllerDelegate-p.html", [
      [ "ORMMAView", "interfaceORMMAView.html", null ]
    ] ],
    [ "GUJNativeAPIInterface", "classGUJNativeAPIInterface.html", [
      [ "ORMMAStateObserver", "interfaceORMMAStateObserver.html", null ],
      [ "ORMMAViewableObserver", "interfaceORMMAViewableObserver.html", null ]
    ] ],
    [ "NSObject", "classNSObject.html", [
      [ "ORMMACall", "interfaceORMMACall.html", null ],
      [ "ORMMACallHandler", "interfaceORMMACallHandler.html", [
        [ "ORMMAAudioCallHandler", "interfaceORMMAAudioCallHandler.html", null ],
        [ "ORMMACalendarCallHandler", "interfaceORMMACalendarCallHandler.html", null ],
        [ "ORMMACameraCallHandler", "interfaceORMMACameraCallHandler.html", null ],
        [ "ORMMACloseCallHandler", "interfaceORMMACloseCallHandler.html", null ],
        [ "ORMMAEmailCallHandler", "interfaceORMMAEmailCallHandler.html", null ],
        [ "ORMMAExpandCallHandler", "interfaceORMMAExpandCallHandler.html", null ],
        [ "ORMMAHideCallHandler", "interfaceORMMAHideCallHandler.html", null ],
        [ "ORMMAMapCallHandler", "interfaceORMMAMapCallHandler.html", null ],
        [ "ORMMAOpenCallHandler", "interfaceORMMAOpenCallHandler.html", null ],
        [ "ORMMAPhoneCallHandler", "interfaceORMMAPhoneCallHandler.html", null ],
        [ "ORMMAResizeCallHandler", "interfaceORMMAResizeCallHandler.html", null ],
        [ "ORMMAShowCallHandler", "interfaceORMMAShowCallHandler.html", null ],
        [ "ORMMASMSCallHandler", "interfaceORMMASMSCallHandler.html", null ],
        [ "ORMMAStorePictureHandler", "interfaceORMMAStorePictureHandler.html", null ],
        [ "ORMMAVideoCallHandler", "interfaceORMMAVideoCallHandler.html", null ]
      ] ],
      [ "ORMMACommand", "interfaceORMMACommand.html", null ],
      [ "ORMMAHTMLTemplate", "interfaceORMMAHTMLTemplate.html", null ],
      [ "ORMMAJavaScriptBridge", "interfaceORMMAJavaScriptBridge.html", null ],
      [ "ORMMAParameter", "interfaceORMMAParameter.html", null ],
      [ "ORMMAResourceBundleManager", "interfaceORMMAResourceBundleManager.html", null ],
      [ "ORMMAUtil", "interfaceORMMAUtil.html", null ]
    ] ],
    [ "<NSObject>", "classNSObject-p.html", [
      [ "<ORMMAWebBrowserDelegate>", "protocolORMMAWebBrowserDelegate-p.html", [
        [ "ORMMAView", "interfaceORMMAView.html", null ]
      ] ]
    ] ],
    [ "ORMMACall(PrivateImplementation)", "categoryORMMACall_07PrivateImplementation_08.html", null ],
    [ "ORMMACommand(PrivateImplementation)", "categoryORMMACommand_07PrivateImplementation_08.html", null ],
    [ "ORMMAInterstitialViewController(PrivateImplementation)", "categoryORMMAInterstitialViewController_07PrivateImplementation_08.html", null ],
    [ "ORMMAJavaScriptBridge(PrivateInitialSequence)", "categoryORMMAJavaScriptBridge_07PrivateInitialSequence_08.html", null ],
    [ "ORMMAJavaScriptBridge(PrivateNotificationHandling)", "categoryORMMAJavaScriptBridge_07PrivateNotificationHandling_08.html", null ],
    [ "ORMMAJavaScriptBridge(PrivateORMMACallHandling)", "categoryORMMAJavaScriptBridge_07PrivateORMMACallHandling_08.html", null ],
    [ "ORMMAParameter(PrivateImplementation)", "categoryORMMAParameter_07PrivateImplementation_08.html", null ],
    [ "ORMMAResourceBundleManager(PrivateImplementation)", "categoryORMMAResourceBundleManager_07PrivateImplementation_08.html", null ],
    [ "ORMMAView(OverriddenSuperMethods)", "categoryORMMAView_07OverriddenSuperMethods_08.html", null ],
    [ "ORMMAView(PrivateImplementation)", "categoryORMMAView_07PrivateImplementation_08.html", null ],
    [ "ORMMAView(WebViewDelegate)", "categoryORMMAView_07WebViewDelegate_08.html", null ],
    [ "ORMMAWebBrowser(PrivateImplementation)", "categoryORMMAWebBrowser_07PrivateImplementation_08.html", null ],
    [ "UIViewController", "classUIViewController.html", [
      [ "ORMMAWebBrowser", "interfaceORMMAWebBrowser.html", null ]
    ] ],
    [ "UIWebView(JavaScriptAlert)", "categoryUIWebView_07JavaScriptAlert_08.html", null ],
    [ "<UIWebViewDelegate>", "classUIWebViewDelegate-p.html", [
      [ "ORMMAView", "interfaceORMMAView.html", null ],
      [ "ORMMAWebBrowser", "interfaceORMMAWebBrowser.html", null ]
    ] ]
];
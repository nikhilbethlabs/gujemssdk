var interfaceORMMAViewableObserver =
[
    [ "init", "interfaceORMMAViewableObserver.html#a3b80fd958061c139f7374c845ea572cf", null ],
    [ "isObserver", "interfaceORMMAViewableObserver.html#ad6ecc7b15d6ee83b9747e26c14a4c577", null ],
    [ "isViewable", "interfaceORMMAViewableObserver.html#a77510b1748dbcb6d69fc529ffed6f421", null ],
    [ "setViewable:", "interfaceORMMAViewableObserver.html#afadaf29a6926263eee3db99d7a87bd02", null ],
    [ "sharedInstance", "interfaceORMMAViewableObserver.html#aa63d63e8dd3c3c23726f3ebdfecdb30c", null ],
    [ "startObserver", "interfaceORMMAViewableObserver.html#af9e99f723520eb229a4ce955d00bc402", null ],
    [ "startObserverWithNotificationReceiver:selector:", "interfaceORMMAViewableObserver.html#a6e3200ee1852b6bbab5d65d451c19967", null ],
    [ "stopObserver", "interfaceORMMAViewableObserver.html#a4a3b4dabc6e13a97cba671580cde5e51", null ],
    [ "stopObserverWithNotificationReceiver:", "interfaceORMMAViewableObserver.html#a2b6c5b2cc95727952f177fe1f8c63fff", null ],
    [ "willPostNotification", "interfaceORMMAViewableObserver.html#a8e6d4e4c848e4c925e5a136d8f06afb2", null ],
    [ "viewable_", "interfaceORMMAViewableObserver.html#a2befbe540ab7a9da6ec691e411be2a94", null ]
];
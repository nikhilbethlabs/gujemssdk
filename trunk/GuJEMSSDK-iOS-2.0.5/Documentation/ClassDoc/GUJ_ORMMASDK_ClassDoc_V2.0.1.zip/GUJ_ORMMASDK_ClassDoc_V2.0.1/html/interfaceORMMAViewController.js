var interfaceORMMAViewController =
[
    [ "adViewController:canDisplayAdView:", "interfaceORMMAViewController.html#a97764b607eaf905971baceda87a33b4f", null ],
    [ "adViewController:didConfigurationFailure:", "interfaceORMMAViewController.html#a713e8c8eaa6c161c03c4849f12055005", null ],
    [ "adViewForType:frame:", "interfaceORMMAViewController.html#af9e55a73ec1f44b6580a30b4a49a28c8", null ],
    [ "bannerView:didFailLoadingAdWithError:", "interfaceORMMAViewController.html#ab56bb6b01321b14e89637257deccbc5e", null ],
    [ "bannerView:receivedEvent:", "interfaceORMMAViewController.html#afc1718c21acd574a9256dc65c0a366bb", null ],
    [ "bannerViewDidHide:", "interfaceORMMAViewController.html#a9951b2a616c3a63c3558046782394a21", null ],
    [ "bannerViewDidShow:", "interfaceORMMAViewController.html#aa12d585b5b984a9f312be45db37a0707", null ],
    [ "bannerViewInitialized:", "interfaceORMMAViewController.html#a24dd1f4c26d3cf7584dec9c59a726925", null ],
    [ "freeInstance", "interfaceORMMAViewController.html#afa4cca0073694b1d056f4470f13686a4", null ],
    [ "instanceForAdspaceId:", "interfaceORMMAViewController.html#a92c419ce427cc437b184d3f767ebf072", null ],
    [ "instanceForAdspaceId:delegate:", "interfaceORMMAViewController.html#a53e271d1a6336987816d53497536d729", null ],
    [ "interstitialView:didFailLoadingAdWithError:", "interfaceORMMAViewController.html#a8f8977f651e673200d6d296d31f243a8", null ],
    [ "interstitialViewDidAppear", "interfaceORMMAViewController.html#a0251c334f2214f30e201efa938571229", null ],
    [ "interstitialViewDidDisappear", "interfaceORMMAViewController.html#a1891e4631ef4c194816617673667a2e9", null ],
    [ "interstitialViewInitialized:", "interfaceORMMAViewController.html#af3d6de94aa6664752d90aba14fff3b2d", null ],
    [ "interstitialViewReceivedEvent:", "interfaceORMMAViewController.html#abc6f151d4e4eeb0c4a1045d9bb50f373", null ],
    [ "interstitialViewWillAppear", "interfaceORMMAViewController.html#ab078e1f6c943bf2c7ac41892467e2bae", null ],
    [ "interstitialViewWillDisappear", "interfaceORMMAViewController.html#a7ef4bec0042b0d395760ef27fafe7d89", null ],
    [ "shouldAutoShowInterstitialViewController:", "interfaceORMMAViewController.html#afd719d52a40eb4b265866314f9bd99fd", null ],
    [ "autoShowInterstitialViewController", "interfaceORMMAViewController.html#a41d06c6893d46f549f8076231225cdb0", null ]
];
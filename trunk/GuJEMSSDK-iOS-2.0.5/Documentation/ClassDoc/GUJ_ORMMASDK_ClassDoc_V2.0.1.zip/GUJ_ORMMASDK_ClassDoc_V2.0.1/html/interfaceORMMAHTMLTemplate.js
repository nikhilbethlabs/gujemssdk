var interfaceORMMAHTMLTemplate =
[
    [ "__createORMMAHTMLTemplate", "interfaceORMMAHTMLTemplate.html#a40770feaa5c0be025b5edfe278a99047", null ],
    [ "__createORRMAHTMLTemplateWithAdData:", "interfaceORMMAHTMLTemplate.html#a816123738ce151545773a0585ed298bc", null ],
    [ "__injectORMMAWithAdData:", "interfaceORMMAHTMLTemplate.html#a920d6de34d67311725916b5e4ffcc489", null ],
    [ "__isFullHTMLAd:", "interfaceORMMAHTMLTemplate.html#a7005ca0adf6dfacae254186663be236f", null ],
    [ "__loadHTMLTemplateResource", "interfaceORMMAHTMLTemplate.html#a0417f36dbbe7c01935ed926f419d36fc", null ],
    [ "__loadNSStringResource:", "interfaceORMMAHTMLTemplate.html#a4601144746641964336752c0e5b28f75", null ],
    [ "__loadORMMAiOSBridgeJavascriptResource", "interfaceORMMAHTMLTemplate.html#a5235d0c933f4f7fb85a4dc435eebe532", null ],
    [ "__loadORMMAJavascriptResource", "interfaceORMMAHTMLTemplate.html#a8aef007f11695ba34375a65da8b323c4", null ],
    [ "freeInstance", "interfaceORMMAHTMLTemplate.html#a17568b80669c07e5ab189a1f9a2b48a2", null ],
    [ "htmlTemplateWithAdData:", "interfaceORMMAHTMLTemplate.html#aca5e9fad9f74e6e8c2052f3d3a30e111", null ],
    [ "ormmaResourceBundle", "interfaceORMMAHTMLTemplate.html#ac03efcf8fc9cb3f1e99c6bcab1cdfb22", null ],
    [ "ormmaTemplate", "interfaceORMMAHTMLTemplate.html#a1f80f68ea933c6d7414b90c980233c87", null ]
];
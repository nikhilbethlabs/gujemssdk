var interfaceORMMAEmailCallHandler =
[
    [ "__hasProperty:", "interfaceORMMAEmailCallHandler.html#aebdaf5b500f2d4ba5be0731299fec1b2", null ],
    [ "__hasProperty:withValue:", "interfaceORMMAEmailCallHandler.html#a15741b956a8b20867a1ab0331d4dd0af", null ],
    [ "__stringValueForProperty:", "interfaceORMMAEmailCallHandler.html#ab7ab6acd600545a8e84c9eedb4bccea8", null ],
    [ "performHandler:", "interfaceORMMAEmailCallHandler.html#a0727639684a8a777155a31f488c14803", null ]
];
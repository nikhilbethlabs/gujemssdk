var categoryORMMAView_07WebViewDelegate_08 =
[
    [ "webView:didFailLoadWithError:", "categoryORMMAView_07WebViewDelegate_08.html#a873106b5574cf04f73bf0d239659bd85", null ],
    [ "webView:shouldStartLoadWithRequest:navigationType:", "categoryORMMAView_07WebViewDelegate_08.html#ae066d33f76d9e678eb3d009e8ad7d132", null ],
    [ "webViewDidFinishLoad:", "categoryORMMAView_07WebViewDelegate_08.html#a00cf0460d08f2a11e9d2df85cfce3a35", null ]
];
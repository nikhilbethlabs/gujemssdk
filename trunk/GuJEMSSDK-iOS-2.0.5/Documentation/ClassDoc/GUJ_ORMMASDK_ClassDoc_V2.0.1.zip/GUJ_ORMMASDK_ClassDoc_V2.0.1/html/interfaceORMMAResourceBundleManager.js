var interfaceORMMAResourceBundleManager =
[
    [ "__loadResourceBundle", "interfaceORMMAResourceBundleManager.html#aacdc0182ad71a2c6a76ded65ef99cbaa", null ],
    [ "__loadResourceBundle:", "interfaceORMMAResourceBundleManager.html#a538ee2a1962e75ce829be1015cec2591", null ],
    [ "freeInstance", "interfaceORMMAResourceBundleManager.html#a6b13198cbc98fbad742226d53880d2dd", null ],
    [ "instanceForBundle:", "interfaceORMMAResourceBundleManager.html#a2c11ce3db32d78fce78ef6252137b07f", null ],
    [ "loadImageResource:", "interfaceORMMAResourceBundleManager.html#abe1a2114688deb2fa163cb9a4c9d25f2", null ],
    [ "loadImageResource:ofType:", "interfaceORMMAResourceBundleManager.html#a61f1636a2042b3a4b1acd3e86122662e", null ],
    [ "loadStringResource:", "interfaceORMMAResourceBundleManager.html#a1b200ebef461f3ab36916f380ed6b6f4", null ],
    [ "loadStringResource:ofType:", "interfaceORMMAResourceBundleManager.html#ad80fe4e5984cc98c71bde93c0ea5a20a", null ],
    [ "error", "interfaceORMMAResourceBundleManager.html#a8792cae3ce468821b0119c41cd75a71f", null ],
    [ "loaded", "interfaceORMMAResourceBundleManager.html#ad25c8ec64be4cf65125763584792f4d0", null ],
    [ "resourceBundle", "interfaceORMMAResourceBundleManager.html#a91131928789173e94f8a2a40e5168daf", null ]
];
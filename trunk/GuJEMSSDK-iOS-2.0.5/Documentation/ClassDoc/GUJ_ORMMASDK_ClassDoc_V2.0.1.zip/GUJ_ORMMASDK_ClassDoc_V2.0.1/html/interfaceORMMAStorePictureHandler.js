var interfaceORMMAStorePictureHandler =
[
    [ "performHandler:", "interfaceORMMAStorePictureHandler.html#a7036d62dd7ad32612e733c212662bd6e", null ]
];
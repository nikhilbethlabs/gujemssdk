var interfaceORMMAUtil =
[
    [ "adViewHasValidAdSize:", "interfaceORMMAUtil.html#a460e15bbe3e3b85ccb1841c50ea05e53", null ],
    [ "changeScrollView:scrolling:", "interfaceORMMAUtil.html#a5a860f9fa5584c04e7ee0984e8d1396e", null ],
    [ "isObviousAdViewRequestForWebView:", "interfaceORMMAUtil.html#a299a35389067c5f80f0f1def29f583bb", null ],
    [ "isORMMAView:", "interfaceORMMAUtil.html#a10976f81062ca07c34668c7ecfab0e16", null ],
    [ "translateNetworkInterface:", "interfaceORMMAUtil.html#adfb3390187ff37ecbf173baf79773def", null ],
    [ "webViewHasORMMAContent:", "interfaceORMMAUtil.html#acaa798b73cea2fbbb0aa727b32a376d5", null ],
    [ "webViewHasORMMAObject:", "interfaceORMMAUtil.html#af9dd3838b0e152e8d0ed3b03205cc74b", null ],
    [ "webViewHasORMMAReadyFunction:", "interfaceORMMAUtil.html#a918b8b9ab29eba969fa57361aa1143d0", null ]
];
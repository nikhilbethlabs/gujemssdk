var interfaceORMMAResizeCallHandler =
[
    [ "__floatForPrameter:", "interfaceORMMAResizeCallHandler.html#abe8ea24aa03a9b7e39fdbb7ac4ef4e0f", null ],
    [ "performHandler:", "interfaceORMMAResizeCallHandler.html#ac80ff051053194fa515b90f2cd87298f", null ]
];
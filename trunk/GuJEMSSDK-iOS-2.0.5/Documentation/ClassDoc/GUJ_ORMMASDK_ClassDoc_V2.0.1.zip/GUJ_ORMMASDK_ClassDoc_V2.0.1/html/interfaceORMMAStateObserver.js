var interfaceORMMAStateObserver =
[
    [ "changeState:", "interfaceORMMAStateObserver.html#a2718b335b104f3200cc79dcb8d3264c6", null ],
    [ "init", "interfaceORMMAStateObserver.html#aefd515d50702ebad58d09dbb38a2fb8e", null ],
    [ "isObserver", "interfaceORMMAStateObserver.html#ad8942ca941b22b21424c6a44a27eda0c", null ],
    [ "sharedInstance", "interfaceORMMAStateObserver.html#a7452239f13ee155064458291be1bfad2", null ],
    [ "startObserver", "interfaceORMMAStateObserver.html#a62bd564ba4166ac042d9c2c2553ceb94", null ],
    [ "startObserverWithNotificationReceiver:selector:", "interfaceORMMAStateObserver.html#ac08829e7608cc2eb89e3bf5de969afa6", null ],
    [ "stopObserver", "interfaceORMMAStateObserver.html#a22a008f8c2da94c9528410a632226d6e", null ],
    [ "stopObserverWithNotificationReceiver:", "interfaceORMMAStateObserver.html#ae4d2aeb7e38de048e868e44c7d23c77e", null ],
    [ "willPostNotification", "interfaceORMMAStateObserver.html#a57c558e752c276d102ead52c401c0795", null ],
    [ "state_", "interfaceORMMAStateObserver.html#a0a450ea8463e8b111ac1e985955d1fc8", null ]
];
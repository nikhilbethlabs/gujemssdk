var interfaceORMMAAudioCallHandler =
[
    [ "__floatForPrameter:", "interfaceORMMAAudioCallHandler.html#a71e323cbc50cc11a46fc6b610ef12b8e", null ],
    [ "__hasProperty:", "interfaceORMMAAudioCallHandler.html#ab3214f45e5c63e85f15681b1afc95d02", null ],
    [ "__hasProperty:withValue:", "interfaceORMMAAudioCallHandler.html#a2b415a267366bddf1b2ac9562456a2f5", null ],
    [ "performHandler:", "interfaceORMMAAudioCallHandler.html#aed77b179f13fba594cdce4dcaf66b9d6", null ]
];
var files =
[
    [ "GUJORMMASDKVersion.h", "GUJORMMASDKVersion_8h.html", "GUJORMMASDKVersion_8h" ],
    [ "ORMMAAudioCallHandler.h", "ORMMAAudioCallHandler_8h.html", [
      [ "ORMMAAudioCallHandler", "interfaceORMMAAudioCallHandler.html", "interfaceORMMAAudioCallHandler" ]
    ] ],
    [ "ORMMAAudioCallHandler.m", "ORMMAAudioCallHandler_8m.html", "ORMMAAudioCallHandler_8m" ],
    [ "ORMMACalendarCallHandler.h", "ORMMACalendarCallHandler_8h.html", [
      [ "ORMMACalendarCallHandler", "interfaceORMMACalendarCallHandler.html", "interfaceORMMACalendarCallHandler" ]
    ] ],
    [ "ORMMACalendarCallHandler.m", "ORMMACalendarCallHandler_8m.html", "ORMMACalendarCallHandler_8m" ],
    [ "ORMMACall.h", "ORMMACall_8h.html", [
      [ "ORMMACall", "interfaceORMMACall.html", "interfaceORMMACall" ],
      [ "ORMMACall(PrivateImplementation)", "categoryORMMACall_07PrivateImplementation_08.html", "categoryORMMACall_07PrivateImplementation_08" ]
    ] ],
    [ "ORMMACall.m", "ORMMACall_8m.html", null ],
    [ "ORMMACallHandler.h", "ORMMACallHandler_8h.html", [
      [ "ORMMACallHandler", "interfaceORMMACallHandler.html", "interfaceORMMACallHandler" ]
    ] ],
    [ "ORMMACallHandler.m", "ORMMACallHandler_8m.html", null ],
    [ "ORMMACameraCallHandler.h", "ORMMACameraCallHandler_8h.html", [
      [ "ORMMACameraCallHandler", "interfaceORMMACameraCallHandler.html", "interfaceORMMACameraCallHandler" ]
    ] ],
    [ "ORMMACameraCallHandler.m", "ORMMACameraCallHandler_8m.html", null ],
    [ "ORMMACloseCallHandler.h", "ORMMACloseCallHandler_8h.html", [
      [ "ORMMACloseCallHandler", "interfaceORMMACloseCallHandler.html", "interfaceORMMACloseCallHandler" ]
    ] ],
    [ "ORMMACloseCallHandler.m", "ORMMACloseCallHandler_8m.html", null ],
    [ "ORMMACommand.h", "ORMMACommand_8h.html", "ORMMACommand_8h" ],
    [ "ORMMACommand.m", "ORMMACommand_8m.html", null ],
    [ "ORMMAConstants.h", "ORMMAConstants_8h.html", "ORMMAConstants_8h" ],
    [ "ORMMAEmailCallHandler.h", "ORMMAEmailCallHandler_8h.html", [
      [ "ORMMAEmailCallHandler", "interfaceORMMAEmailCallHandler.html", "interfaceORMMAEmailCallHandler" ]
    ] ],
    [ "ORMMAEmailCallHandler.m", "ORMMAEmailCallHandler_8m.html", "ORMMAEmailCallHandler_8m" ],
    [ "ORMMAExpandCallHandler.h", "ORMMAExpandCallHandler_8h.html", [
      [ "ORMMAExpandCallHandler", "interfaceORMMAExpandCallHandler.html", "interfaceORMMAExpandCallHandler" ]
    ] ],
    [ "ORMMAExpandCallHandler.m", "ORMMAExpandCallHandler_8m.html", null ],
    [ "ORMMAHideCallHandler.h", "ORMMAHideCallHandler_8h.html", [
      [ "ORMMAHideCallHandler", "interfaceORMMAHideCallHandler.html", "interfaceORMMAHideCallHandler" ]
    ] ],
    [ "ORMMAHideCallHandler.m", "ORMMAHideCallHandler_8m.html", null ],
    [ "ORMMAHTMLTemplate.h", "ORMMAHTMLTemplate_8h.html", [
      [ "ORMMAHTMLTemplate", "interfaceORMMAHTMLTemplate.html", "interfaceORMMAHTMLTemplate" ]
    ] ],
    [ "ORMMAHTMLTemplate.m", "ORMMAHTMLTemplate_8m.html", "ORMMAHTMLTemplate_8m" ],
    [ "ORMMAInterstitialViewController.h", "ORMMAInterstitialViewController_8h.html", [
      [ "ORMMAInterstitialViewController", "interfaceORMMAInterstitialViewController.html", "interfaceORMMAInterstitialViewController" ],
      [ "ORMMAInterstitialViewController(PrivateImplementation)", "categoryORMMAInterstitialViewController_07PrivateImplementation_08.html", "categoryORMMAInterstitialViewController_07PrivateImplementation_08" ]
    ] ],
    [ "ORMMAInterstitialViewController.m", "ORMMAInterstitialViewController_8m.html", null ],
    [ "ORMMAJavaScriptBridge.h", "ORMMAJavaScriptBridge_8h.html", [
      [ "ORMMAJavaScriptBridge", "interfaceORMMAJavaScriptBridge.html", "interfaceORMMAJavaScriptBridge" ],
      [ "ORMMAJavaScriptBridge(PrivateInitialSequence)", "categoryORMMAJavaScriptBridge_07PrivateInitialSequence_08.html", "categoryORMMAJavaScriptBridge_07PrivateInitialSequence_08" ],
      [ "ORMMAJavaScriptBridge(PrivateNotificationHandling)", "categoryORMMAJavaScriptBridge_07PrivateNotificationHandling_08.html", "categoryORMMAJavaScriptBridge_07PrivateNotificationHandling_08" ],
      [ "ORMMAJavaScriptBridge(PrivateORMMACallHandling)", "categoryORMMAJavaScriptBridge_07PrivateORMMACallHandling_08.html", "categoryORMMAJavaScriptBridge_07PrivateORMMACallHandling_08" ]
    ] ],
    [ "ORMMAJavaScriptBridge.m", "ORMMAJavaScriptBridge_8m.html", "ORMMAJavaScriptBridge_8m" ],
    [ "ORMMAMapCallHandler.h", "ORMMAMapCallHandler_8h.html", [
      [ "ORMMAMapCallHandler", "interfaceORMMAMapCallHandler.html", "interfaceORMMAMapCallHandler" ]
    ] ],
    [ "ORMMAMapCallHandler.m", "ORMMAMapCallHandler_8m.html", null ],
    [ "ORMMAOpenCallHandler.h", "ORMMAOpenCallHandler_8h.html", [
      [ "ORMMAOpenCallHandler", "interfaceORMMAOpenCallHandler.html", "interfaceORMMAOpenCallHandler" ]
    ] ],
    [ "ORMMAOpenCallHandler.m", "ORMMAOpenCallHandler_8m.html", null ],
    [ "ORMMAParameter.h", "ORMMAParameter_8h.html", [
      [ "ORMMAParameter", "interfaceORMMAParameter.html", "interfaceORMMAParameter" ],
      [ "ORMMAParameter(PrivateImplementation)", "categoryORMMAParameter_07PrivateImplementation_08.html", "categoryORMMAParameter_07PrivateImplementation_08" ]
    ] ],
    [ "ORMMAParameter.m", "ORMMAParameter_8m.html", null ],
    [ "ORMMAPhoneCallHandler.h", "ORMMAPhoneCallHandler_8h.html", [
      [ "ORMMAPhoneCallHandler", "interfaceORMMAPhoneCallHandler.html", "interfaceORMMAPhoneCallHandler" ]
    ] ],
    [ "ORMMAPhoneCallHandler.m", "ORMMAPhoneCallHandler_8m.html", "ORMMAPhoneCallHandler_8m" ],
    [ "ORMMAResizeCallHandler.h", "ORMMAResizeCallHandler_8h.html", [
      [ "ORMMAResizeCallHandler", "interfaceORMMAResizeCallHandler.html", "interfaceORMMAResizeCallHandler" ]
    ] ],
    [ "ORMMAResizeCallHandler.m", "ORMMAResizeCallHandler_8m.html", null ],
    [ "ORMMAResourceBundleManager.h", "ORMMAResourceBundleManager_8h.html", [
      [ "ORMMAResourceBundleManager", "interfaceORMMAResourceBundleManager.html", "interfaceORMMAResourceBundleManager" ],
      [ "ORMMAResourceBundleManager(PrivateImplementation)", "categoryORMMAResourceBundleManager_07PrivateImplementation_08.html", "categoryORMMAResourceBundleManager_07PrivateImplementation_08" ]
    ] ],
    [ "ORMMAResourceBundleManager.m", "ORMMAResourceBundleManager_8m.html", null ],
    [ "ORMMAShowCallHandler.h", "ORMMAShowCallHandler_8h.html", [
      [ "ORMMAShowCallHandler", "interfaceORMMAShowCallHandler.html", "interfaceORMMAShowCallHandler" ]
    ] ],
    [ "ORMMAShowCallHandler.m", "ORMMAShowCallHandler_8m.html", null ],
    [ "ORMMASMSCallHandler.h", "ORMMASMSCallHandler_8h.html", [
      [ "ORMMASMSCallHandler", "interfaceORMMASMSCallHandler.html", "interfaceORMMASMSCallHandler" ]
    ] ],
    [ "ORMMASMSCallHandler.m", "ORMMASMSCallHandler_8m.html", "ORMMASMSCallHandler_8m" ],
    [ "ORMMAStateObserver.h", "ORMMAStateObserver_8h.html", [
      [ "ORMMAStateObserver", "interfaceORMMAStateObserver.html", "interfaceORMMAStateObserver" ]
    ] ],
    [ "ORMMAStateObserver.m", "ORMMAStateObserver_8m.html", "ORMMAStateObserver_8m" ],
    [ "ORMMAStorePictureHandler.h", "ORMMAStorePictureHandler_8h.html", [
      [ "ORMMAStorePictureHandler", "interfaceORMMAStorePictureHandler.html", "interfaceORMMAStorePictureHandler" ]
    ] ],
    [ "ORMMAStorePictureHandler.m", "ORMMAStorePictureHandler_8m.html", null ],
    [ "ORMMAUtil.h", "ORMMAUtil_8h.html", [
      [ "ORMMAUtil", "interfaceORMMAUtil.html", "interfaceORMMAUtil" ]
    ] ],
    [ "ORMMAUtil.m", "ORMMAUtil_8m.html", null ],
    [ "ORMMAVideoCallHandler.h", "ORMMAVideoCallHandler_8h.html", [
      [ "ORMMAVideoCallHandler", "interfaceORMMAVideoCallHandler.html", "interfaceORMMAVideoCallHandler" ]
    ] ],
    [ "ORMMAVideoCallHandler.m", "ORMMAVideoCallHandler_8m.html", "ORMMAVideoCallHandler_8m" ],
    [ "ORMMAView+OverriddenSuperMethods.h", "ORMMAView_09OverriddenSuperMethods_8h.html", [
      [ "ORMMAView(OverriddenSuperMethods)", "categoryORMMAView_07OverriddenSuperMethods_08.html", "categoryORMMAView_07OverriddenSuperMethods_08" ]
    ] ],
    [ "ORMMAView+OverriddenSuperMethods.m", "ORMMAView_09OverriddenSuperMethods_8m.html", null ],
    [ "ORMMAView+PrivateImplementation.h", "ORMMAView_09PrivateImplementation_8h.html", [
      [ "ORMMAView(PrivateImplementation)", "categoryORMMAView_07PrivateImplementation_08.html", "categoryORMMAView_07PrivateImplementation_08" ]
    ] ],
    [ "ORMMAView+PrivateImplementation.m", "ORMMAView_09PrivateImplementation_8m.html", null ],
    [ "ORMMAView+WebViewDelegate.h", "ORMMAView_09WebViewDelegate_8h.html", [
      [ "ORMMAView(WebViewDelegate)", "categoryORMMAView_07WebViewDelegate_08.html", "categoryORMMAView_07WebViewDelegate_08" ]
    ] ],
    [ "ORMMAView+WebViewDelegate.m", "ORMMAView_09WebViewDelegate_8m.html", null ],
    [ "ORMMAView.h", "ORMMAView_8h.html", [
      [ "UIWebView(JavaScriptAlert)", "categoryUIWebView_07JavaScriptAlert_08.html", "categoryUIWebView_07JavaScriptAlert_08" ],
      [ "ORMMAView", "interfaceORMMAView.html", "interfaceORMMAView" ]
    ] ],
    [ "ORMMAView.m", "ORMMAView_8m.html", null ],
    [ "ORMMAViewableObserver.h", "ORMMAViewableObserver_8h.html", [
      [ "ORMMAViewableObserver", "interfaceORMMAViewableObserver.html", "interfaceORMMAViewableObserver" ]
    ] ],
    [ "ORMMAViewableObserver.m", "ORMMAViewableObserver_8m.html", "ORMMAViewableObserver_8m" ],
    [ "ORMMAViewController.h", "ORMMAViewController_8h.html", [
      [ "ORMMAViewController", "interfaceORMMAViewController.html", "interfaceORMMAViewController" ]
    ] ],
    [ "ORMMAViewController.m", "ORMMAViewController_8m.html", [
      [ "ORMMAViewController(PrivateImplementation)", "categoryORMMAViewController_07PrivateImplementation_08.html", null ]
    ] ],
    [ "ORMMAWebBrowser.h", "ORMMAWebBrowser_8h.html", [
      [ "<ORMMAWebBrowserDelegate>", "protocolORMMAWebBrowserDelegate-p.html", "protocolORMMAWebBrowserDelegate-p" ],
      [ "ORMMAWebBrowser", "interfaceORMMAWebBrowser.html", "interfaceORMMAWebBrowser" ],
      [ "ORMMAWebBrowser(PrivateImplementation)", "categoryORMMAWebBrowser_07PrivateImplementation_08.html", "categoryORMMAWebBrowser_07PrivateImplementation_08" ]
    ] ],
    [ "ORMMAWebBrowser.m", "ORMMAWebBrowser_8m.html", null ]
];
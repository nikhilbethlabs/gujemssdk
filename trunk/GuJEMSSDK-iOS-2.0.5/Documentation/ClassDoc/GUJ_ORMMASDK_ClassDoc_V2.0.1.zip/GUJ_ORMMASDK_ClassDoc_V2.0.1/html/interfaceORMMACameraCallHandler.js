var interfaceORMMACameraCallHandler =
[
    [ "performHandler:", "interfaceORMMACameraCallHandler.html#a157e667c28fa827deab6d01dda8b46d0", null ]
];
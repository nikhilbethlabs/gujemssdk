var searchData=
[
  ['observevalueforkeypath_3aofobject_3achange_3acontext_3a',['observeValueForKeyPath:ofObject:change:context:',['../categoryORMMAJavaScriptBridge_07PrivateORMMACallHandling_08.html#aa8f6227e9678f8a4decaa994e2885226',1,'ORMMAJavaScriptBridge(PrivateORMMACallHandling)::observeValueForKeyPath:ofObject:change:context:()'],['../interfaceORMMAJavaScriptBridge.html#aa8f6227e9678f8a4decaa994e2885226',1,'ORMMAJavaScriptBridge::observeValueForKeyPath:ofObject:change:context:()']]],
  ['openexternal_3a',['openExternal:',['../categoryORMMAWebBrowser_07PrivateImplementation_08.html#abfbab93681d96ef68d8c7c4019759de1',1,'ORMMAWebBrowser(PrivateImplementation)::openExternal:()'],['../interfaceORMMAWebBrowser.html#abfbab93681d96ef68d8c7c4019759de1',1,'ORMMAWebBrowser::openExternal:()']]]
];

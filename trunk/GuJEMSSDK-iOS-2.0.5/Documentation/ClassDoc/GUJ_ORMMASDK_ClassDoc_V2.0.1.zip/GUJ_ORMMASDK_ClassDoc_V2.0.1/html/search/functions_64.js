var searchData=
[
  ['dismiss',['dismiss',['../interfaceORMMAInterstitialViewController.html#af84c80d49e43f4acf1a5aa90bbce88b4',1,'ORMMAInterstitialViewController::dismiss()'],['../interfaceORMMAWebBrowser.html#ad1f5d3c9d1b4af8e49973ed21997911d',1,'ORMMAWebBrowser::dismiss()']]],
  ['dismiss_3a',['dismiss:',['../interfaceORMMAInterstitialViewController.html#ac9a831151dd12b9da4193887c68b4289',1,'ORMMAInterstitialViewController']]]
];

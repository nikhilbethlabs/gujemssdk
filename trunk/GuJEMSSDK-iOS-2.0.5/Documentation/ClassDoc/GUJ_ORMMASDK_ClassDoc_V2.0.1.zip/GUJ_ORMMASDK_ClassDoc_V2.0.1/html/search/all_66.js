var searchData=
[
  ['firechangeeventcommand_3a',['fireChangeEventCommand:',['../interfaceORMMACommand.html#a321d8d7a53f27ae4f42ba5d032af1661',1,'ORMMACommand']]],
  ['fireerroreventcommand_3akey_3a',['fireErrorEventCommand:key:',['../interfaceORMMACommand.html#a9f0f7ed719e0363ca0cfd4dcc9369711',1,'ORMMACommand']]],
  ['fireshakeeventcommand_3a',['fireShakeEventCommand:',['../interfaceORMMACommand.html#a375fdf37a4fc331dd1ab260c97d1818c',1,'ORMMACommand']]],
  ['freeinstance',['freeInstance',['../interfaceORMMAHTMLTemplate.html#a17568b80669c07e5ab189a1f9a2b48a2',1,'ORMMAHTMLTemplate::freeInstance()'],['../interfaceORMMAResourceBundleManager.html#a6b13198cbc98fbad742226d53880d2dd',1,'ORMMAResourceBundleManager::freeInstance()'],['../interfaceORMMAWebBrowser.html#af5e225d26c8ba742b0ddfb884a585be5',1,'ORMMAWebBrowser::freeInstance()'],['../interfaceORMMAViewController.html#afa4cca0073694b1d056f4470f13686a4',1,'ORMMAViewController::freeInstance()']]]
];

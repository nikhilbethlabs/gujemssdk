var searchData=
[
  ['loadimageresource_3a',['loadImageResource:',['../interfaceORMMAResourceBundleManager.html#abe1a2114688deb2fa163cb9a4c9d25f2',1,'ORMMAResourceBundleManager']]],
  ['loadimageresource_3aoftype_3a',['loadImageResource:ofType:',['../interfaceORMMAResourceBundleManager.html#a61f1636a2042b3a4b1acd3e86122662e',1,'ORMMAResourceBundleManager']]],
  ['loadstringresource_3a',['loadStringResource:',['../interfaceORMMAResourceBundleManager.html#a1b200ebef461f3ab36916f380ed6b6f4',1,'ORMMAResourceBundleManager']]],
  ['loadstringresource_3aoftype_3a',['loadStringResource:ofType:',['../interfaceORMMAResourceBundleManager.html#ad80fe4e5984cc98c71bde93c0ea5a20a',1,'ORMMAResourceBundleManager']]]
];

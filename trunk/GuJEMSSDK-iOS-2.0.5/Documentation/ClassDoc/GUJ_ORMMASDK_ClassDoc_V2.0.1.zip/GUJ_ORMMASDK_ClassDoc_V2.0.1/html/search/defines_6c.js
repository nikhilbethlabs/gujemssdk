var searchData=
[
  ['lib_5fguj_5formma_5fsdk_5fmajor_5fversion',['LIB_GUJ_ORMMA_SDK_MAJOR_VERSION',['../GUJORMMASDKVersion_8h.html#a01cbf0a0730ae691bb004e60b69925dc',1,'GUJORMMASDKVersion.h']]],
  ['lib_5fguj_5formma_5fsdk_5fminor_5fversion',['LIB_GUJ_ORMMA_SDK_MINOR_VERSION',['../GUJORMMASDKVersion_8h.html#a21d96506bd5c3ef19051c3b437b1d2bd',1,'GUJORMMASDKVersion.h']]],
  ['lib_5fguj_5formma_5fsdk_5frevision',['LIB_GUJ_ORMMA_SDK_REVISION',['../GUJORMMASDKVersion_8h.html#a11f447fc3d8e3da1cac58b1cb50e1757',1,'GUJORMMASDKVersion.h']]],
  ['lib_5fguj_5formma_5fsdk_5fversion',['LIB_GUJ_ORMMA_SDK_VERSION',['../GUJORMMASDKVersion_8h.html#afc84602b9c0b9d99c68760d913590f78',1,'GUJORMMASDKVersion.h']]],
  ['lib_5fguj_5formma_5fsdk_5fversion_5fcheck',['LIB_GUJ_ORMMA_SDK_VERSION_CHECK',['../GUJORMMASDKVersion_8h.html#aa94fc1944e5c00b5032d2cae79c17d19',1,'GUJORMMASDKVersion.h']]]
];

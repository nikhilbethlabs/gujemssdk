var searchData=
[
  ['lib_5fguj_5formma_5fsdk_5fmajor_5fversion',['LIB_GUJ_ORMMA_SDK_MAJOR_VERSION',['../GUJORMMASDKVersion_8h.html#a01cbf0a0730ae691bb004e60b69925dc',1,'GUJORMMASDKVersion.h']]],
  ['lib_5fguj_5formma_5fsdk_5fminor_5fversion',['LIB_GUJ_ORMMA_SDK_MINOR_VERSION',['../GUJORMMASDKVersion_8h.html#a21d96506bd5c3ef19051c3b437b1d2bd',1,'GUJORMMASDKVersion.h']]],
  ['lib_5fguj_5formma_5fsdk_5frevision',['LIB_GUJ_ORMMA_SDK_REVISION',['../GUJORMMASDKVersion_8h.html#a11f447fc3d8e3da1cac58b1cb50e1757',1,'GUJORMMASDKVersion.h']]],
  ['lib_5fguj_5formma_5fsdk_5fversion',['LIB_GUJ_ORMMA_SDK_VERSION',['../GUJORMMASDKVersion_8h.html#afc84602b9c0b9d99c68760d913590f78',1,'GUJORMMASDKVersion.h']]],
  ['lib_5fguj_5formma_5fsdk_5fversion_5fcheck',['LIB_GUJ_ORMMA_SDK_VERSION_CHECK',['../GUJORMMASDKVersion_8h.html#aa94fc1944e5c00b5032d2cae79c17d19',1,'GUJORMMASDKVersion.h']]],
  ['loaded',['loaded',['../interfaceORMMAResourceBundleManager.html#ad25c8ec64be4cf65125763584792f4d0',1,'ORMMAResourceBundleManager']]],
  ['loadimageresource_3a',['loadImageResource:',['../interfaceORMMAResourceBundleManager.html#abe1a2114688deb2fa163cb9a4c9d25f2',1,'ORMMAResourceBundleManager']]],
  ['loadimageresource_3aoftype_3a',['loadImageResource:ofType:',['../interfaceORMMAResourceBundleManager.html#a61f1636a2042b3a4b1acd3e86122662e',1,'ORMMAResourceBundleManager']]],
  ['loadstringresource_3a',['loadStringResource:',['../interfaceORMMAResourceBundleManager.html#a1b200ebef461f3ab36916f380ed6b6f4',1,'ORMMAResourceBundleManager']]],
  ['loadstringresource_3aoftype_3a',['loadStringResource:ofType:',['../interfaceORMMAResourceBundleManager.html#ad80fe4e5984cc98c71bde93c0ea5a20a',1,'ORMMAResourceBundleManager']]]
];

var searchData=
[
  ['modalviewcontrollerdidappear_3a',['modalViewControllerDidAppear:',['../interfaceORMMAView.html#a88c183fea656ac6604640cebd3b339f7',1,'ORMMAView']]],
  ['modalviewcontrollerdiddisappear',['modalViewControllerDidDisappear',['../interfaceORMMAView.html#a329e2544f120461d5fe6bc5cfed962a6',1,'ORMMAView']]],
  ['modalviewcontrollerwillappear',['modalViewControllerWillAppear',['../interfaceORMMAView.html#a7eeedd485f86180f91608a77ce67fc3d',1,'ORMMAView']]],
  ['modalviewcontrollerwilldisappear_3a',['modalViewControllerWillDisappear:',['../interfaceORMMAView.html#a010f451ab1ee4188de1c4732aa0bcfad',1,'ORMMAView']]]
];

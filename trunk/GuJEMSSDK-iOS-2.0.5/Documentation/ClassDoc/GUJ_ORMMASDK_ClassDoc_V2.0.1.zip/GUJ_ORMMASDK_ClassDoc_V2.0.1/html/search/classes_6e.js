var searchData=
[
  ['nsobject',['NSObject',['../classNSObject.html',1,'']]],
  ['nsobject_2dp',['NSObject-p',['../classNSObject-p.html',1,'']]]
];

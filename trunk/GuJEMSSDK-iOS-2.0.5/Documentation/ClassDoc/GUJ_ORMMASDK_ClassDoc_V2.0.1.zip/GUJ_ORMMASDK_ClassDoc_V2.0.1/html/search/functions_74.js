var searchData=
[
  ['touchesbegan_3awithevent_3a',['touchesBegan:withEvent:',['../interfaceORMMAView.html#a0ab3b793abb23c5181c3fd50cb6f2ec2',1,'ORMMAView']]],
  ['translatenetworkinterface_3a',['translateNetworkInterface:',['../interfaceORMMAUtil.html#adfb3390187ff37ecbf173baf79773def',1,'ORMMAUtil']]]
];

var searchData=
[
  ['ormma_5ferror_5fcode_5ffailed_5floading_5fresource',['ORMMA_ERROR_CODE_FAILED_LOADING_RESOURCE',['../ORMMAConstants_8h.html#a2cb1a4c603453d487d9ca8a5dc2bd276',1,'ORMMAConstants.h']]],
  ['ormma_5ferror_5fcode_5ffailed_5floading_5fresource_5fbundle',['ORMMA_ERROR_CODE_FAILED_LOADING_RESOURCE_BUNDLE',['../ORMMAConstants_8h.html#a41221717b583b1455c3e031a1dc7955a',1,'ORMMAConstants.h']]],
  ['ormma_5ferror_5fcode_5ffirst_5fresponder_5fnot_5ffound',['ORMMA_ERROR_CODE_FIRST_RESPONDER_NOT_FOUND',['../ORMMAConstants_8h.html#a86bf22c36daf0111ee416e29da8474c0',1,'ORMMAConstants.h']]],
  ['ormma_5ferror_5fcode_5fillegal_5fbanner_5fstate',['ORMMA_ERROR_CODE_ILLEGAL_BANNER_STATE',['../ORMMAConstants_8h.html#a65f98acc6af6ac3ddfe13c011cf0345a',1,'ORMMAConstants.h']]],
  ['ormma_5ferror_5fcode_5fillegal_5fcontent_5fsize',['ORMMA_ERROR_CODE_ILLEGAL_CONTENT_SIZE',['../ORMMAConstants_8h.html#a2e5e8f2e260d02a57758bebe6c4d29ad',1,'ORMMAConstants.h']]],
  ['ormma_5ferror_5fcode_5fillegal_5formma_5fstate',['ORMMA_ERROR_CODE_ILLEGAL_ORMMA_STATE',['../ORMMAConstants_8h.html#a8b86b4caba0ba0d325accf10bf2e5320',1,'ORMMAConstants.h']]],
  ['ormma_5ferror_5fcode_5funable_5fto_5fcreate_5fad',['ORMMA_ERROR_CODE_UNABLE_TO_CREATE_AD',['../ORMMAConstants_8h.html#a41056f56a0e1d2360c8e89e43c100631',1,'ORMMAConstants.h']]],
  ['ormma_5ferror_5fcode_5funable_5fto_5fparse_5formma_5fcall',['ORMMA_ERROR_CODE_UNABLE_TO_PARSE_ORMMA_CALL',['../ORMMAConstants_8h.html#a5fe7bbd5d49263769f8ebbfbaecc2cbe',1,'ORMMAConstants.h']]],
  ['ormma_5ferror_5fcode_5funknown_5fbanner_5fformat',['ORMMA_ERROR_CODE_UNKNOWN_BANNER_FORMAT',['../ORMMAConstants_8h.html#ab281ceb1a9393da61d0baa83eb73624e',1,'ORMMAConstants.h']]],
  ['ormma_5fevent_5fmessage_5fad_5fclicked',['ORMMA_EVENT_MESSAGE_AD_CLICKED',['../ORMMAConstants_8h.html#a868587b941e4181f79ec008b678f233b',1,'ORMMAConstants.h']]],
  ['ormma_5fevent_5fmessage_5freload_5fad_5fview',['ORMMA_EVENT_MESSAGE_RELOAD_AD_VIEW',['../ORMMAConstants_8h.html#aa6d413ecdfae91f5f5f6a0a7d979613a',1,'ORMMAConstants.h']]]
];

var interfaceORMMACall =
[
    [ "__isORMMACall:", "interfaceORMMACall.html#ac0fb1fb4db8223c0aa6e3a35fa273cbc", null ],
    [ "__isORMMAServiceCall:", "interfaceORMMACall.html#a69eee34b1b4a9c46a7a568b7961f2511", null ],
    [ "__isValidCallString:", "interfaceORMMACall.html#a09203adb20e3d728b778482c615c4cb5", null ],
    [ "__parseCallString:", "interfaceORMMACall.html#aba08307fc085d8fc6aafddbba0e096fa", null ],
    [ "isCallForIdentifier:", "interfaceORMMACall.html#a3383e354426adfbbca63b0300e8869cc", null ],
    [ "isServiceCall", "interfaceORMMACall.html#a5a3caee0efaf826a96b557e32a4481dd", null ],
    [ "isValidCall", "interfaceORMMACall.html#a6b3331e3826bf1fbdee7a279475165a2", null ],
    [ "name", "interfaceORMMACall.html#afd42a0b6808ffc7b52cf966050bff4b1", null ],
    [ "parse:", "interfaceORMMACall.html#aa0c385b41bbd9d8a5b8009d00d35e765", null ],
    [ "serviceCallValue", "interfaceORMMACall.html#a8096e80eec6f633bf56301b838e32696", null ],
    [ "value", "interfaceORMMACall.html#a538cd2a5c4d417a52b3b23f51c20800b", null ],
    [ "callName", "interfaceORMMACall.html#a14a282c064109069de955316b5ba0532", null ],
    [ "callValue", "interfaceORMMACall.html#a038e33c5bb86a358f0313a6a66b01685", null ],
    [ "error", "interfaceORMMACall.html#a7bda342aafdfd5899f86bd6d16503cda", null ],
    [ "ormmaCall", "interfaceORMMACall.html#a4396343dba82879f33cae223e0a374e5", null ],
    [ "serviceCall", "interfaceORMMACall.html#a28d2e370f37824b072b1adf4358aa0c5", null ],
    [ "serviceCallValue", "interfaceORMMACall.html#a03bb6ee32cfc93b85e362aaf3b0fcc0b", null ]
];
/*
 * BSD LICENSE
 * Copyright (c) 2012, Mobile Unit of G+J Electronic Media Sales GmbH, Hamburg All rights reserved.
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer .
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * The source code is just allowed for private use, not for commercial use.
 *
 */
#import "GUJAdView.h"
#import "GUJServerConnection.h"

@implementation GUJAdView (Private)

- (id)initWithFrame:(CGRect)frame andDelegate:(id<GUJAdViewDelegate>)delegate
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:[UIColor clearColor]];
        self->delegate_ = delegate;
        self->initialOrigin_ = CGPointMake(0.0,frame.origin.y);
    }
    return self;
}

- (id<GUJAdViewDelegate>)__adViewDelegate
{
    return delegate_;
}

- (CGPoint*)__initialOrigin
{
    return &initialOrigin_;
}

- (void)__performOptimizedAdServerRequest
{
    @autoreleasepool {
        GUJServerConnection *_connection = [[GUJServerConnection alloc] initWithAdConfiguration:[self adConfiguration]];
        NSLog(@"[AD-BannerType-Default ] %i",[[self adConfiguration] bannerType]);
        [_connection sendAdServerRequest];
        if( [_connection error] != nil ) {
            [self performSelectorOnMainThread:@selector(__adDataFailedLoading) withObject:nil waitUntilDone:NO];
            if( [GUJUtil typeIsNotNil:delegate_ andRespondsToSelector:@selector(view:didFailToLoadAdWithUrl:andError:)] ) {
                [delegate_ view:self didFailToLoadAdWithUrl:[_connection url] andError:[_connection error]];
            }
        } else {
            adData_ = [_connection adData];
            [self performSelectorOnMainThread:@selector(__adDataLoaded:) withObject:adData_ waitUntilDone:NO];            
            if( [GUJUtil typeIsNotNil:delegate_ andRespondsToSelector:@selector(view:didLoadAd:)] ) {
                [delegate_ view:self didLoadAd:adData_];
            }
        }
        NSLog(@"[AD-BannerType-Response ] %i",[[self adConfiguration] bannerType]);
        _connection = nil;
        adIsLoading_ = NO;
    }
}

- (void)__performAdServerRequest
{
    [self performSelectorInBackground:@selector(__performOptimizedAdServerRequest) withObject:nil];
}

- (void)__loadAd
{
    if( !adIsLoading_ ) {
        adIsLoading_ = YES;
         
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(__loadAd) object:nil];
        if( [GUJUtil typeIsNotNil:delegate_ andRespondsToSelector:@selector(viewWillLoadAd:)] ) {
            [delegate_ viewWillLoadAd:self];
        };
        [self performSelectorOnMainThread:@selector(__performAdServerRequest) withObject:nil waitUntilDone:NO];
  
        if( [[self adConfiguration] reloadInterval] > 0.0 ) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, [[self adConfiguration] reloadInterval] * NSEC_PER_SEC), dispatch_get_main_queue(), ^(void){
                [self __loadAd];
            });
        }
    }
}

- (void)__loadAdNotifcation:(NSNotification*)notification
{
    /*
     * You can analyze the incomming notification if needed.
     */
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(__loadAd) object:nil];
    [[GUJNotificationObserver sharedInstance] removeFromNotificationQueue:self name:notification.name];
    [self __loadAd];
}

#pragma mark protected methods
/*!
 * Override this method in extending Classes to perform various changes, parsing, etc.
 * with the ad data object.
 *
 * Also, this is a good place to initilaize or start native interfaces.
 */
- (void)__adDataLoaded:(GUJAdData*)adData
{
#pragma unused(adData)
    // Custom data handling
}

/*!
 * Override this method to free adData, release or hide the banner view,
 * and/ or release native interfaces in custom implementations.
 */
- (void)__adDataFailedLoading
{
    // Custom data handling
}

/*!
 * Unloads the current adView without destroying it.
 * Means: Free adData, reset ServerConnection and maybe unload or stop native interfaces.
 */
- (void)__unload
{
    // Custom data handling
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    // Serverconnection uses strong properties, so only ios 4.2 can release it    
    adData_ = nil;
    _logd_tm(self, @"__unload",nil);
}

- (void)__free
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [self removeFromSuperview];
    _logd_tm(self, @"__free",nil);
}

@end

@implementation GUJAdView

- (id)initWithFrame:(CGRect)frame
{
    return [self initWithFrame:frame andDelegate:nil];
}


@end

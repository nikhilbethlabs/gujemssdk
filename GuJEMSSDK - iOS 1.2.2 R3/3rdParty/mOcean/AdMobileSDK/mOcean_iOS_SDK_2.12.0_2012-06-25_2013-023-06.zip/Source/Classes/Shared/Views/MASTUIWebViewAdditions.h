//
//  UIWebViewAdditions.h
//  AdMobileSDK
//
//  Created by Constantine Mureev on 3/3/11.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// do nothing, just for make this catagory linked
void useCatagory9();

@interface UIWebView (UIView_mOcean)

- (void)disableBouncesForWebView;

@end
